import React from 'react';
import {
  LayoutDashboard,
  Compass,
  ShieldCheck,
  FileSearch,
  Activity,
  ShieldAlert,
  BarChart3,
  Globe,
  Lock,
  Bot,
  Settings,
  HelpCircle,
  AlertTriangle,
  Brain,
  Network,
  Mail,
  KeyRound,
  Code2,
  Beaker,
  Award,
  Flame,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  quarantinedCount: number;
  suspiciousCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  quarantinedCount,
  suspiciousCount,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, category: 'Core' },
    { id: 'threat_heatmap', label: 'Threat Heatmap', icon: Flame, category: 'Core' },
    { id: 'landing', label: 'Overview / Intro', icon: Compass, category: 'Core' },
    { id: 'scan', label: 'Scan Center', icon: ShieldCheck, category: 'Detection' },
    { id: 'analyzer', label: 'AI File Analyzer', icon: FileSearch, category: 'Detection' },
    {
      id: 'behavior',
      label: 'Behavior Monitor',
      icon: Activity,
      category: 'Detection',
      badge: suspiciousCount > 0 ? suspiciousCount : undefined,
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    },
    { id: 'adaptive_ai', label: 'Adaptive AI Engine', icon: Brain, category: 'AI & Advanced' },
    { id: 'network_map', label: 'Network & Cloud Map', icon: Network, category: 'AI & Advanced' },
    { id: 'email_security', label: 'Email & Web Shield', icon: Mail, category: 'AI & Advanced' },
    { id: 'credential_safety', label: 'Credential & Health', icon: KeyRound, category: 'AI & Advanced' },
    { id: 'incident_response', label: 'Incident Response & Forensics', icon: ShieldAlert, category: 'SOC & Forensics' },
    { id: 'devsec_ops', label: 'DevSecOps & Supply Chain', icon: Code2, category: 'SOC & Forensics' },
    { id: 'multi_agent', label: 'Multi-Agent Consensus', icon: Bot, category: 'SOC & Forensics' },
    { id: 'security_lab', label: 'Defensive Lab & Sandbox', icon: Beaker, category: 'Labs & Education' },
    { id: 'achievements_reports', label: 'Achievements & Reports', icon: Award, category: 'Labs & Education' },
    {
      id: 'quarantine',
      label: 'Quarantine & Threats',
      icon: ShieldAlert,
      category: 'Protection',
      badge: quarantinedCount > 0 ? quarantinedCount : undefined,
      badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    },
    { id: 'phishing', label: 'Phishing Shield', icon: Globe, category: 'Protection' },
    { id: 'ransomware', label: 'Ransomware Guard', icon: Lock, category: 'Protection', highlight: true },
    { id: 'analytics', label: 'SOC Analytics', icon: BarChart3, category: 'Intelligence' },
    { id: 'assistant', label: 'AI Assistant', icon: Bot, category: 'Intelligence' },
    { id: 'settings', label: 'Settings', icon: Settings, category: 'System' },
  ];

  return (
    <aside className="w-64 flex-shrink-0 border-r border-slate-800/80 bg-slate-950/80 backdrop-blur-md p-4 flex flex-col justify-between hidden lg:flex min-h-[calc(100vh-61px)]">
      <div className="space-y-6">
        <div>
          <p className="px-3 text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">
            Operations Menu
          </p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-500/15 via-emerald-500/10 to-transparent text-emerald-400 border border-emerald-500/30 shadow-md shadow-emerald-500/5'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`w-4 h-4 transition-colors ${
                        isActive ? 'text-emerald-400' : 'text-slate-500 group-hover:text-slate-300'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${item.badgeColor}`}>
                      {item.badge}
                    </span>
                  )}

                  {item.highlight && !item.badge && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      LIVE DEMO
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Threat Status Card */}
        <div className="p-3.5 rounded-xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-medium">Agent Fleet</span>
            <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> 5/5 Sync
            </span>
          </div>
          <p className="text-[11px] text-slate-500 leading-snug">
            Real-time multi-platform endpoint protection active across all connected OS kernels.
          </p>
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-slate-800/60 text-[11px] text-slate-500 flex items-center justify-between">
        <span className="font-mono">Engine: Gemini 3.6</span>
        <button
          onClick={() => onSelectTab('assistant')}
          className="flex items-center gap-1 text-slate-400 hover:text-emerald-400 transition-colors"
        >
          <HelpCircle className="w-3.5 h-3.5" /> Help
        </button>
      </div>
    </aside>
  );
};
