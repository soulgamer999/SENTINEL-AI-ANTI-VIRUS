import React, { useState } from 'react';
import { Mail, Globe, ShieldAlert, Sparkles, Send, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';

export const EmailSecurityAnalyzer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'email' | 'web' | 'predictive'>('email');

  // Email form state
  const [senderHeader, setSenderHeader] = useState('billing-update@verify-account-security-alert.net');
  const [emailBody, setEmailBody] = useState(
    'URGENT: Your payroll direct deposit account has been suspended due to unverified tax details. Click here within 12 hours to re-verify your SSN and banking credentials or direct deposit will be held.'
  );
  const [isAnalyzingEmail, setIsAnalyzingEmail] = useState(false);
  const [emailResult, setEmailResult] = useState<any>(null);

  // Predictive state
  const mockPredictive = [
    { title: 'Suspicious Combination: Encrypted Zip + New Domain', probability: '88%', urgency: 'CRITICAL', reason: 'Email attachment matching ransomware delivery tactics observed across external SOC feeds.' },
    { title: 'Pattern Match: Executive Impersonation Request', probability: '74%', urgency: 'HIGH', reason: 'Sender address uses visually similar domain variation (typosquatting).' },
  ];

  const handleAnalyzeEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzingEmail(true);
    setEmailResult(null);

    try {
      const res = await fetch('/api/analyze-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailBody, senderHeader }),
      });
      const data = await res.json();
      setEmailResult(data);
    } catch (err) {
      console.error('Email analysis error', err);
    } finally {
      setIsAnalyzingEmail(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 p-6 border border-purple-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-purple-500/20 border border-purple-500/40 text-purple-400">
              <Mail className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/40 text-purple-300 font-mono text-xs font-bold">
                  COMMUNICATION SHIELD
                </span>
                <span className="font-mono text-xs text-slate-400">Email & Web Threat Inspection</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Email Security, Web & Predictive Alerts</h1>
              <p className="text-xs text-slate-400">
                Inspect email bodies, headers, domain links, and predictive behavioral threat combinations.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('email')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'email' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Mail className="w-4 h-4" /> Email Analyzer
            </button>
            <button
              onClick={() => setActiveTab('web')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'web' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Globe className="w-4 h-4" /> Web Protection
            </button>
            <button
              onClick={() => setActiveTab('predictive')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'predictive' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <ShieldAlert className="w-4 h-4" /> Predictive Threat Alerts
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'email' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" /> Inspect Email Content
            </h2>

            <form onSubmit={handleAnalyzeEmail} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Sender Header / From Address</label>
                <input
                  type="text"
                  value={senderHeader}
                  onChange={(e) => setSenderHeader(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:border-purple-500 focus:outline-none"
                  placeholder="e.g. sender@domain.com"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Email Body Content</label>
                <textarea
                  rows={5}
                  value={emailBody}
                  onChange={(e) => setEmailBody(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-sans focus:border-purple-500 focus:outline-none"
                  placeholder="Paste email text here..."
                />
              </div>

              <button
                type="submit"
                disabled={isAnalyzingEmail}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-mono text-xs font-bold transition-all shadow-lg shadow-purple-900/30 flex items-center justify-center gap-2"
              >
                {isAnalyzingEmail ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Analyzing with Gemini Email Engine...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" /> Run Deep Email Analysis
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase">Inspection Diagnosis</h2>

            {emailResult ? (
              <div className="space-y-4 animate-fade-in">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-mono text-slate-400 uppercase">Threat Score</div>
                    <div
                      className={`text-2xl font-mono font-bold ${
                        emailResult.threatScore > 50 ? 'text-red-400' : 'text-emerald-400'
                      }`}
                    >
                      {emailResult.threatScore} / 100
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${
                      emailResult.threatScore > 50 ? 'bg-red-500/20 text-red-300 border border-red-500/40' : 'bg-emerald-500/20 text-emerald-300'
                    }`}
                  >
                    {emailResult.threatCategory}
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-mono text-slate-400 font-bold uppercase">Evidence Flags</div>
                  <ul className="space-y-1.5">
                    {emailResult.evidence?.map((ev: string, idx: number) => (
                      <li key={idx} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-300 flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{ev}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-500/30 text-xs text-slate-300 space-y-1">
                  <div className="font-mono text-purple-300 font-bold">Recommended Action</div>
                  <p>{emailResult.recommendedAction}</p>
                </div>
              </div>
            ) : (
              <div className="h-64 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-center p-6 text-slate-500 font-mono text-xs">
                Submit an email body to analyze sender authenticity, urgency triggers, and phishing threat score.
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'web' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Web & Domain Protection Shield</h2>
          <p className="text-xs text-slate-400">
            SentinelAI automatically monitors web page requests, TLS certificate anomalies, and deceptive domain registrations.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-xs font-mono text-slate-400">Web Filter Engine</div>
              <div className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" /> Real-time URL Inspection Active
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-xs font-mono text-slate-400">Domains Checked Today</div>
              <div className="text-lg font-mono font-bold text-white">1,842 URLs</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-xs font-mono text-slate-400">Blocked Malicious Sites</div>
              <div className="text-lg font-mono font-bold text-red-400">14 Domains</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'predictive' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Predictive Threat Intelligence Alerts</h2>
          <div className="space-y-3">
            {mockPredictive.map((item, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-white">{item.title}</h3>
                  <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-mono text-[10px] font-bold">
                    Probability: {item.probability}
                  </span>
                </div>
                <p className="text-xs text-slate-300">{item.reason}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
