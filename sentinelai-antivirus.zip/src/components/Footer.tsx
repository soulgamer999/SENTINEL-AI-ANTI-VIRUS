import React from 'react';
import { Shield, Monitor, Smartphone, Lock } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-slate-800/80 bg-slate-950 px-4 lg:px-8 py-6 text-xs text-slate-500 space-y-4">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span className="font-mono font-bold text-slate-300">
            SENTINEL<span className="text-emerald-400">AI</span> ANTIVIRUS
          </span>
          <span className="text-[10px] text-slate-600">v4.8.2</span>
        </div>

        {/* Platform compatibility */}
        <div className="flex items-center gap-2 text-[11px] font-mono">
          <span className="text-slate-400">Cross-Platform Deployment:</span>
          <span className="text-emerald-400 flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
            <Monitor className="w-3 h-3" /> Windows • Mac • Linux
          </span>
          <span className="text-cyan-400 flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
            <Smartphone className="w-3 h-3" /> Android • iOS
          </span>
        </div>

        {/* Privacy Note */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>Privacy & Ephemeral Memory Protected</span>
        </div>
      </div>

      <div className="text-[10px] text-slate-600 text-center leading-relaxed max-w-4xl mx-auto border-t border-slate-900 pt-3">
        SentinelAI is a defensive cybersecurity and threat-analysis platform. Classifications provided by heuristic rules and Gemini AI models represent risk assessments based on behavioral indicators and file metadata, not guaranteed absolute diagnoses.
      </div>
    </footer>
  );
};
