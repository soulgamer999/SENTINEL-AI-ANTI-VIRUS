import React, { useState } from 'react';
import { Brain, Sparkles, TrendingUp, ShieldCheck, AlertCircle, Database, RefreshCw, Bookmark, Cpu } from 'lucide-react';

export const AdaptiveAiProfile: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'memory' | 'baseline'>('profile');
  const [confidenceScore, setConfidenceScore] = useState<number>(92.4);

  const mockPatterns = [
    { id: 'pat-1', category: 'Phishing', frequency: 'High', description: 'Repeated financial urgency emails targeting accounts payable.', count: 18, risk: 'HIGH' },
    { id: 'pat-2', category: 'Suspicious Execution', frequency: 'Medium', description: 'Powershell invoking encoded command lines from Temp folder.', count: 7, risk: 'CRITICAL' },
    { id: 'pat-3', category: 'Network Anomaly', frequency: 'Low', description: 'Outbound HTTP requests to unassigned dynamic DNS domains.', count: 3, risk: 'SUSPICIOUS' },
  ];

  const mockThreatMemory = [
    { id: 'mem-1', ioc: 'SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', category: 'Ransomware Sample', dateAdded: '2026-03-01', occurrences: 4 },
    { id: 'mem-2', ioc: 'IP: 198.51.100.44 (Suspicious C2 Server)', category: 'Network IOC', dateAdded: '2026-03-03', occurrences: 12 },
    { id: 'mem-3', ioc: 'Pattern: cmd.exe /c powershell -W Hidden -Enc', category: 'Behavioral TTP', dateAdded: '2026-03-04', occurrences: 8 },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-900/30 via-slate-900 to-cyan-900/30 p-6 border border-emerald-500/30 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
              <Brain className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold">
                  ADAPTIVE AI ENGINE v3.6
                </span>
                <span className="font-mono text-xs text-slate-400">Continuous Learning Active</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Adaptive Security Profile & Threat Memory</h1>
              <p className="text-xs text-slate-400">
                Self-learning engine that tracks behavioral baselines, threat frequencies, and historical indicators.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <div>
              <div className="text-[10px] font-mono text-slate-400 uppercase">AI Confidence Score</div>
              <div className="text-lg font-mono font-bold text-emerald-400">{confidenceScore}%</div>
            </div>
          </div>
        </div>

        {/* Sub Navigation */}
        <div className="flex items-center gap-2 mt-6 border-b border-slate-800/80 pb-3">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'profile'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-lg shadow-emerald-900/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" /> AI Security Profile
          </button>
          <button
            onClick={() => setActiveSubTab('memory')}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'memory'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-lg shadow-emerald-900/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" /> Threat Memory Store
          </button>
          <button
            onClick={() => setActiveSubTab('baseline')}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'baseline'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-lg shadow-emerald-900/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" /> User Baseline Analysis
          </button>
        </div>
      </div>

      {activeSubTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
              <h2 className="text-sm font-bold font-mono text-white uppercase flex items-center justify-between">
                <span>Observed Threat Patterns</span>
                <span className="text-xs font-normal text-slate-400">Auto-Categorized</span>
              </h2>

              <div className="space-y-3">
                {mockPatterns.map((pat) => (
                  <div
                    key={pat.id}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-all flex items-start justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold">
                          {pat.category}
                        </span>
                        <span className="text-xs font-mono text-slate-400">Freq: {pat.frequency}</span>
                      </div>
                      <p className="text-xs text-slate-200 font-sans">{pat.description}</p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-mono font-bold text-red-400 block">{pat.count} Events</span>
                      <span className="text-[10px] font-mono text-slate-400">{pat.risk} Risk</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-3">
              <h2 className="text-sm font-bold font-mono text-white uppercase">AI Security Recommendations</h2>
              <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-mono font-bold">
                  <ShieldCheck className="w-4 h-4" /> Recommended Policy Adjustment
                </div>
                <p>
                  Enable automated PowerShell execution blocking in Quick Scan mode. The AI detected 7 PowerShell invocations matching suspicious obfuscation patterns.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
              <h3 className="text-xs font-bold font-mono text-slate-400 uppercase">Recent System Anomalies</h3>
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5" /> High File Entropy Spike
                  </div>
                  <p className="text-[11px] text-slate-400">Multiple compressed archives created in AppData\\Local.</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
                  <div className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5" /> Unusual Network Port Traffic
                  </div>
                  <p className="text-[11px] text-slate-400">Outbound SMB request on non-standard internal port 4450.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'memory' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold font-mono text-white uppercase">Threat Memory Repository</h2>
              <p className="text-xs text-slate-400">Cross-analyzed Indicators of Compromise (IOCs) remembered by SentinelAI.</p>
            </div>
            <button className="px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-mono font-bold">
              Export Memory Store
            </button>
          </div>

          <div className="space-y-2">
            {mockThreatMemory.map((mem) => (
              <div key={mem.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <div className="font-mono text-emerald-300 font-bold">{mem.ioc}</div>
                  <div className="text-[11px] text-slate-400 font-mono">Category: {mem.category} | Added: {mem.dateAdded}</div>
                </div>
                <div className="text-right">
                  <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[10px]">
                    Matched {mem.occurrences}x
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'baseline' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">User Behavioral Baseline</h2>
          <p className="text-xs text-slate-400">
            SentinelAI establishes normal operating patterns (active hours, standard file execution types, network traffic bandwidth) to detect deviations.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs font-mono text-slate-400">Normal Active Hours</div>
              <div className="text-lg font-mono font-bold text-white mt-1">08:00 - 19:30</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs font-mono text-slate-400">Avg File Scans/Day</div>
              <div className="text-lg font-mono font-bold text-emerald-400 mt-1">1,420</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs font-mono text-slate-400">Baseline Stability</div>
              <div className="text-lg font-mono font-bold text-cyan-400 mt-1">98.2% Normal</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
