import React, { useState, useEffect } from 'react';
import {
  Lock,
  Play,
  Pause,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  FileText,
  Shield,
  Activity,
  Terminal,
  Sparkles,
} from 'lucide-react';

export const RansomwareGuard: React.FC = () => {
  const [isRunningSim, setIsRunningSim] = useState(false);
  const [modifiedCount, setModifiedCount] = useState(0);
  const [intercepted, setIntercepted] = useState(false);
  const [virtualFiles, setVirtualFiles] = useState<
    Array<{ name: string; status: 'Clean' | 'Modified' | 'Protected' }>
  >([]);

  // Initialize 500 virtual simulated files
  useEffect(() => {
    const list = Array.from({ length: 50 }, (_, i) => ({
      name: `document_${i + 1}.docx`,
      status: 'Clean' as const,
    }));
    setVirtualFiles(list);
  }, []);

  const handleStartSimulation = () => {
    setIsRunningSim(true);
    setModifiedCount(0);
    setIntercepted(false);

    // Reset virtual files to Clean
    setVirtualFiles((prev) => prev.map((f) => ({ ...f, status: 'Clean' })));

    let current = 0;
    const interval = setInterval(() => {
      current++;
      setModifiedCount(current);

      setVirtualFiles((prev) =>
        prev.map((f, idx) => (idx === current - 1 ? { ...f, status: 'Modified' } : f))
      );

      // SentinelAI Intercepts at 12 rapid modifications!
      if (current >= 12) {
        clearInterval(interval);
        setIsRunningSim(false);
        setIntercepted(true);

        // Lock remaining files to Protected state
        setVirtualFiles((prev) =>
          prev.map((f, idx) => (idx >= 12 ? { ...f, status: 'Protected' } : f))
        );
      }
    }, 200);
  };

  const handleRestoreBackup = () => {
    setVirtualFiles((prev) => prev.map((f) => ({ ...f, status: 'Clean' })));
    setModifiedCount(0);
    setIntercepted(false);
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Lock className="w-6 h-6 text-purple-400" /> Ransomware Rapid File Traversal Guard (Safe Demo)
          </h1>
          <p className="text-xs text-slate-400">
            Interactive demonstration showing how SentinelAI detects high-volume rapid file modifications and freezes suspicious processes before encryption occurs.
          </p>
        </div>
      </div>

      {/* Control Box */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-slate-950 border border-purple-500/30 space-y-4 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-mono font-bold text-purple-400 uppercase flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> SAFE DEMONSTRATION MODE
            </span>
            <h2 className="text-base font-bold text-white font-mono">
              Simulate High-Speed Mass File Modification Attack
            </h2>
            <p className="text-xs text-slate-400 max-w-xl">
              Clicking start will simulate an unverified executable attempting to rapidly rewrite 50 virtual mock files in browser memory. SentinelAI will automatically detect the anomaly and suspend the process.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {!isRunningSim && !intercepted && (
              <button
                onClick={handleStartSimulation}
                className="px-6 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-slate-950 font-black text-xs font-mono tracking-wider transition-all shadow-lg shadow-purple-500/20 active:scale-95 flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" /> START RANSOMWARE SIMULATION
              </button>
            )}

            {intercepted && (
              <button
                onClick={handleRestoreBackup}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-400 font-bold text-xs font-mono transition-all flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" /> RESET MOCK DIRECTORY
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Alert Banner when Intercepted */}
      {intercepted && (
        <div className="p-6 rounded-2xl bg-rose-950/90 border-2 border-rose-500 text-rose-100 space-y-4 shadow-2xl animate-bounce" style={{ animationIterationCount: 2 }}>
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-rose-400 flex-shrink-0 animate-pulse" />
            <div>
              <h2 className="text-lg font-black font-mono tracking-wide uppercase text-white">
                🚨 POSSIBLE RANSOMWARE BEHAVIOR INTERCEPTED!
              </h2>
              <p className="text-xs text-rose-200">
                SentinelAI behavioral guard detected mass file modification rate (12 modifications in {`<`}2 seconds).
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs font-mono">
            <div className="p-3 rounded-xl bg-rose-900/60 border border-rose-500/40">
              <span className="text-rose-300 block text-[10px] uppercase">Attempted PID</span>
              <span className="text-white font-bold text-sm">PID 8812 (untrusted_burst.exe)</span>
            </div>
            <div className="p-3 rounded-xl bg-rose-900/60 border border-rose-500/40">
              <span className="text-rose-300 block text-[10px] uppercase">Sentinel Action</span>
              <span className="text-emerald-300 font-bold text-sm">PROCESS FROZEN & ISOLATED</span>
            </div>
            <div className="p-3 rounded-xl bg-rose-900/60 border border-rose-500/40">
              <span className="text-rose-300 block text-[10px] uppercase">Directory Status</span>
              <span className="text-cyan-300 font-bold text-sm">38 FILES PROTECTED & LOCKED</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={handleRestoreBackup}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs font-mono"
            >
              PAUSE ACTIVITY & PROTECT FILES
            </button>
            <span className="text-xs text-rose-300 font-mono">
              0 encrypted files leaked to network.
            </span>
          </div>
        </div>
      )}

      {/* Virtual Mock Directory Grid Visualizer */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <span className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
            <FileText className="w-4 h-4 text-purple-400" /> Virtual Mock Directory (~/Documents/UserFiles/)
          </span>
          <span className="text-xs font-mono text-slate-400">
            Files Modified: <strong className="text-rose-400">{modifiedCount}</strong> / 50
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-10 gap-2 text-[10px] font-mono">
          {virtualFiles.map((file, idx) => (
            <div
              key={idx}
              className={`p-2 rounded-lg border text-center truncate transition-all ${
                file.status === 'Clean'
                  ? 'bg-slate-900 border-slate-800 text-slate-400'
                  : file.status === 'Modified'
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300 font-bold animate-pulse'
                  : 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
              }`}
            >
              <FileText className="w-4 h-4 mx-auto mb-1 opacity-70" />
              <span className="truncate block">{file.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
