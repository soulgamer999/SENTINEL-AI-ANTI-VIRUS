import React from 'react';
import {
  BarChart3,
  PieChart as PieChartIcon,
  TrendingUp,
  Clock,
  ShieldCheck,
  AlertTriangle,
  History,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  LineChart,
  Line,
} from 'recharts';
import { analyticsData, initialThreatHistory } from '../data/mockData';

export const AnalyticsView: React.FC = () => {
  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-emerald-400" /> SOC Intelligence & Threat Analytics
          </h1>
          <p className="text-xs text-slate-400">
            Real-time visual breakdown of endpoint scan volumes, threat categories, and security score progression.
          </p>
        </div>
      </div>

      {/* Top Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Threats Over Time Area Chart */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" /> Endpoint Scan Volume & Threat Volume
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Last 8 Days</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analyticsData.threatsOverTime} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSafe" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorHighRisk" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '12px', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="safeScans" stroke="#10b981" fillOpacity={1} fill="url(#colorSafe)" name="Safe Scans" />
                <Area type="monotone" dataKey="highRisk" stroke="#f43f5e" fillOpacity={1} fill="url(#colorHighRisk)" name="Threats Blocked" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Breakdown Donut Chart */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
              <PieChartIcon className="w-4 h-4 text-cyan-400" /> Threat Vectors & Categories
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Distribution</span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={analyticsData.categoryBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {analyticsData.categoryBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '12px', fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-wrap justify-center gap-3 text-[11px] font-mono text-slate-400">
            {analyticsData.categoryBreakdown.map((item) => (
              <span key={item.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                {item.name} ({item.value}%)
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Security Score History & Category Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Score History Line Chart */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Security Score Progression
          </h3>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analyticsData.securityScoreTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="week" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                <YAxis domain={[70, 100]} stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '12px', fontSize: '11px' }} />
                <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981', r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Detection Bar Chart */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-400" /> Detection Categories
          </h3>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.categoryBreakdown} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 9 }} />
                <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '12px', fontSize: '11px' }} />
                <Bar dataKey="value" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Threat History Timeline */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase flex items-center gap-2">
          <History className="w-4 h-4 text-amber-400" /> Historical Security Events Timeline
        </h3>

        <div className="space-y-3">
          {initialThreatHistory.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-xl bg-slate-900 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-bold">{item.timestamp}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] ${
                      item.level === 'HIGH_RISK'
                        ? 'bg-rose-500/20 text-rose-400'
                        : item.level === 'SUSPICIOUS'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {item.level}
                  </span>
                </div>
                <p className="text-white font-bold">{item.title}</p>
                <p className="text-slate-400 text-[11px]">{item.description}</p>
              </div>

              <span className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400 text-[11px] font-bold self-start sm:self-center">
                {item.actionTaken}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
