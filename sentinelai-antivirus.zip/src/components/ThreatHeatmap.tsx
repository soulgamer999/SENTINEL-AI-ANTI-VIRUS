import React, { useState, useEffect } from 'react';
import {
  Flame,
  Globe,
  Radio,
  ShieldAlert,
  Zap,
  Play,
  Pause,
  Filter,
  RefreshCw,
  AlertTriangle,
  Server,
  Activity,
  Maximize2,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface ThreatEvent {
  id: string;
  sourceRegion: string;
  sourceCoords: [number, number]; // [x, y] in SVG canvas (0-800, 0-400)
  targetRegion: string;
  targetCoords: [number, number];
  type: 'Ransomware' | 'Zero-Day' | 'DDoS' | 'Phishing' | 'Port Scan';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  ip: string;
  timestamp: string;
}

const REGION_COORDS: Record<string, [number, number]> = {
  'North America': [220, 140],
  'South America': [300, 280],
  'Europe': [440, 120],
  'Africa': [460, 240],
  'Asia-Pacific': [620, 160],
  'Oceania': [700, 310],
};

export const ThreatHeatmap: React.FC = () => {
  const [isLive, setIsLive] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedContinent, setSelectedContinent] = useState<string | null>('North America');
  const [attackFeed, setAttackFeed] = useState<ThreatEvent[]>([]);
  const [activeArcs, setActiveArcs] = useState<ThreatEvent[]>([]);

  // Initialize initial attack feed
  useEffect(() => {
    const initialEvents: ThreatEvent[] = [
      {
        id: 'atk-1',
        sourceRegion: 'Asia-Pacific',
        sourceCoords: REGION_COORDS['Asia-Pacific'],
        targetRegion: 'North America',
        targetCoords: REGION_COORDS['North America'],
        type: 'Zero-Day',
        severity: 'CRITICAL',
        ip: '185.220.101.5',
        timestamp: 'Just now',
      },
      {
        id: 'atk-2',
        sourceRegion: 'Europe',
        sourceCoords: REGION_COORDS['Europe'],
        targetRegion: 'North America',
        targetCoords: REGION_COORDS['North America'],
        type: 'Ransomware',
        severity: 'CRITICAL',
        ip: '194.26.29.112',
        timestamp: '2s ago',
      },
      {
        id: 'atk-3',
        sourceRegion: 'Africa',
        sourceCoords: REGION_COORDS['Africa'],
        targetRegion: 'Europe',
        targetCoords: REGION_COORDS['Europe'],
        type: 'DDoS',
        severity: 'HIGH',
        ip: '41.203.77.10',
        timestamp: '5s ago',
      },
      {
        id: 'atk-4',
        sourceRegion: 'South America',
        sourceCoords: REGION_COORDS['South America'],
        targetRegion: 'North America',
        targetCoords: REGION_COORDS['North America'],
        type: 'Phishing',
        severity: 'MEDIUM',
        ip: '200.122.18.9',
        timestamp: '9s ago',
      },
      {
        id: 'atk-5',
        sourceRegion: 'Asia-Pacific',
        sourceCoords: REGION_COORDS['Asia-Pacific'],
        targetRegion: 'Oceania',
        targetCoords: REGION_COORDS['Oceania'],
        type: 'Port Scan',
        severity: 'MEDIUM',
        ip: '113.210.42.88',
        timestamp: '12s ago',
      },
    ];

    setAttackFeed(initialEvents);
    setActiveArcs(initialEvents.slice(0, 3));
  }, []);

  // Live attack generator loop
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const regions = Object.keys(REGION_COORDS);
      const src = regions[Math.floor(Math.random() * regions.length)];
      let tgt = regions[Math.floor(Math.random() * regions.length)];
      while (tgt === src) {
        tgt = regions[Math.floor(Math.random() * regions.length)];
      }

      const types: ('Ransomware' | 'Zero-Day' | 'DDoS' | 'Phishing' | 'Port Scan')[] = [
        'Ransomware',
        'Zero-Day',
        'DDoS',
        'Phishing',
        'Port Scan',
      ];
      const severities: ('CRITICAL' | 'HIGH' | 'MEDIUM')[] = ['CRITICAL', 'HIGH', 'MEDIUM'];

      const newEvt: ThreatEvent = {
        id: `atk-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        sourceRegion: src,
        sourceCoords: REGION_COORDS[src],
        targetRegion: tgt,
        targetCoords: REGION_COORDS[tgt],
        type: types[Math.floor(Math.random() * types.length)],
        severity: severities[Math.floor(Math.random() * severities.length)],
        ip: `${Math.floor(Math.random() * 200 + 10)}.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}`,
        timestamp: 'Just now',
      };

      setAttackFeed((prev) => [newEvt, ...prev.slice(0, 25)]);
      setActiveArcs((prev) => [newEvt, ...prev.slice(0, 5)]);
    }, 2800);

    return () => clearInterval(interval);
  }, [isLive]);

  const filteredFeed = attackFeed.filter((evt) => {
    if (selectedCategory !== 'ALL' && evt.type !== selectedCategory) return false;
    if (selectedContinent && evt.targetRegion !== selectedContinent && evt.sourceRegion !== selectedContinent) {
      return false;
    }
    return true;
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      default:
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
    }
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-rose-400 font-mono text-xs font-bold uppercase tracking-wider">
            <Flame className="w-4 h-4 animate-pulse" /> Live Cyber Threat Telemetry
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight mt-1">
            GLOBAL THREAT HEATMAP
          </h1>
          <p className="text-xs text-slate-400">
            Real-time simulated global cyber attack visualization & multi-continental threat vectors.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsLive(!isLive)}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
              isLive
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                : 'bg-amber-500/15 border-amber-500/40 text-amber-300'
            }`}
          >
            {isLive ? (
              <>
                <Pause className="w-3.5 h-3.5" /> LIVE STREAMING ACTIVE
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" /> RESUME LIVE STREAM
              </>
            )}
          </button>
        </div>
      </div>

      {/* Interactive SVG Heatmap Canvas */}
      <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-4 sm:p-6 shadow-2xl overflow-hidden">
        {/* Ambient background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
            <Radio className="w-4 h-4 text-emerald-400 animate-ping" />
            <span>Continental Heatmap Canvas</span>
            <span className="text-slate-500">| SVG Vector Arc Visualization</span>
          </div>

          <div className="flex items-center gap-2">
            {['ALL', 'Ransomware', 'Zero-Day', 'DDoS', 'Phishing'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition-all ${
                  selectedCategory === cat
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* SVG World Map Vector Representation */}
        <div className="relative w-full aspect-[2/1] max-h-[420px] bg-slate-900/60 rounded-xl border border-slate-800/80 p-2 overflow-hidden flex items-center justify-center">
          <svg viewBox="0 0 800 400" className="w-full h-full select-none">
            {/* Grid Lines */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(51, 65, 85, 0.3)" strokeWidth="0.5" />
              </pattern>
              <linearGradient id="arcGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.2" />
              </linearGradient>
            </defs>

            <rect width="800" height="400" fill="url(#grid)" />

            {/* Continental Silhouette Shapes */}
            {/* North America */}
            <path
              d="M 120 80 Q 180 60 260 90 T 280 180 T 180 200 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('North America')}
            />
            {/* South America */}
            <path
              d="M 260 220 Q 320 240 310 320 T 260 360 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('South America')}
            />
            {/* Europe */}
            <path
              d="M 400 80 Q 480 70 480 130 T 420 150 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('Europe')}
            />
            {/* Africa */}
            <path
              d="M 410 170 Q 490 170 490 280 T 430 300 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('Africa')}
            />
            {/* Asia-Pacific */}
            <path
              d="M 500 70 Q 680 60 700 180 T 580 200 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('Asia-Pacific')}
            />
            {/* Oceania */}
            <path
              d="M 660 270 Q 740 270 730 340 T 670 330 Z"
              fill="#1e293b"
              stroke="#334155"
              strokeWidth="1"
              className="hover:fill-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedContinent('Oceania')}
            />

            {/* Dynamic Animated Attack Arcs */}
            {activeArcs.map((arc) => {
              const [x1, y1] = arc.sourceCoords;
              const [x2, y2] = arc.targetCoords;
              const mx = (x1 + x2) / 2;
              const my = Math.min(y1, y2) - 40; // Curve arc control point

              return (
                <g key={arc.id}>
                  <path
                    d={`M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`}
                    fill="none"
                    stroke="url(#arcGrad)"
                    strokeWidth="2"
                    strokeDasharray="6 4"
                    className="animate-pulse"
                  />
                  {/* Origin pulse */}
                  <circle cx={x1} cy={y1} r="4" fill="#f43f5e" className="animate-ping opacity-75" />
                  <circle cx={x1} cy={y1} r="3" fill="#f43f5e" />

                  {/* Target pulse */}
                  <circle cx={x2} cy={y2} r="5" fill="#10b981" />
                </g>
              );
            })}

            {/* Regional Hotspot Nodes & Labels */}
            {Object.entries(REGION_COORDS).map(([name, [x, y]]) => {
              const isSelected = selectedContinent === name;
              return (
                <g
                  key={name}
                  transform={`translate(${x}, ${y})`}
                  className="cursor-pointer group"
                  onClick={() => setSelectedContinent(name)}
                >
                  <circle
                    r={isSelected ? '12' : '8'}
                    className={`transition-all ${
                      isSelected ? 'fill-rose-500/30 stroke-rose-400' : 'fill-slate-800 stroke-emerald-500'
                    }`}
                    strokeWidth="2"
                  />
                  <circle r="4" fill={isSelected ? '#f43f5e' : '#10b981'} />
                  <text
                    y="22"
                    textAnchor="middle"
                    fill={isSelected ? '#f43f5e' : '#cbd5e1'}
                    fontSize="10"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    {name}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Region Quick Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-4 font-mono text-xs">
          {Object.keys(REGION_COORDS).map((region) => {
            const count = attackFeed.filter(
              (a) => a.sourceRegion === region || a.targetRegion === region
            ).length;
            const isSelected = selectedContinent === region;
            return (
              <button
                key={region}
                onClick={() => setSelectedContinent(region)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 font-bold'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="text-[10px] uppercase text-slate-500 truncate">{region}</div>
                <div className="text-sm font-bold text-white mt-0.5">{count * 18 + 42} /min</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Regional Attack Feed & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attack Feed Table */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Live Cyber Attack Telemetry Log
              {selectedContinent && (
                <span className="text-emerald-400 text-[10px] font-normal font-mono">
                  (Filtered: {selectedContinent})
                </span>
              )}
            </h3>
            {selectedContinent && (
              <button
                onClick={() => setSelectedContinent(null)}
                className="text-[10px] font-mono text-cyan-400 hover:underline"
              >
                Clear Region Filter
              </button>
            )}
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1 font-mono text-xs">
            {filteredFeed.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                No active attack vectors matching criteria.
              </div>
            ) : (
              filteredFeed.map((evt) => (
                <div
                  key={evt.id}
                  className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 flex items-center justify-between gap-3 hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getSeverityBadge(
                        evt.severity
                      )}`}
                    >
                      {evt.type}
                    </span>
                    <div className="min-w-0 truncate">
                      <div className="text-slate-200 font-bold truncate">
                        {evt.sourceRegion} → {evt.targetRegion}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        Origin IP: {evt.ip} • Threat Vector Identified
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-400 flex-shrink-0">{evt.timestamp}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Selected Region Threat Profile */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 shadow-xl">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
            <Globe className="w-4 h-4 text-cyan-400" />
            Regional Threat Profile: {selectedContinent || 'Global Aggregate'}
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 space-y-1">
              <span className="text-slate-500 text-[10px] uppercase">Primary Threat Vector</span>
              <p className="text-sm font-bold text-rose-400">Zero-Day Exploits & Ransomware Canaries</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 space-y-1">
              <span className="text-slate-500 text-[10px] uppercase">Sentinel Shield Status</span>
              <p className="text-sm font-bold text-emerald-400">100% Intercept & Containment Active</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 space-y-1">
              <span className="text-slate-500 text-[10px] uppercase">Automated Defense Action</span>
              <p className="text-slate-300 text-xs">
                Adaptive Firewall rules auto-deploying to edge reverse proxies to block suspicious ASN ranges.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
