import React, { useState } from 'react';
import {
  ShieldAlert,
  Trash2,
  RotateCcw,
  Eye,
  X,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Shield,
  Hash,
} from 'lucide-react';
import { QuarantinedItem } from '../types';

interface QuarantineCenterProps {
  items: QuarantinedItem[];
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

export const QuarantineCenter: React.FC<QuarantineCenterProps> = ({
  items,
  onRestore,
  onDelete,
  onClearAll,
}) => {
  const [selectedInspectItem, setSelectedInspectItem] = useState<QuarantinedItem | null>(null);

  const activeItems = items.filter((i) => i.status === 'Quarantined');

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-rose-400" /> Isolated Threat Quarantine Vault
          </h1>
          <p className="text-xs text-slate-400">
            Isolated storage environment for intercepted suspicious executables, trojans, and phishing attachments.
          </p>
        </div>

        {activeItems.length > 0 && (
          <button
            onClick={onClearAll}
            className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-rose-500/20"
          >
            <Trash2 className="w-4 h-4" /> PURGE ALL QUARANTINED ITEMS
          </button>
        )}
      </div>

      {/* Stats Header Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-mono text-slate-400">Active Quarantined</span>
          <p className="text-xl font-bold font-mono text-rose-400 mt-0.5">{activeItems.length} Files</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-mono text-slate-400">Restored Safe Files</span>
          <p className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
            {items.filter((i) => i.status === 'Restored').length}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] uppercase font-mono text-slate-400">Permanently Deleted</span>
          <p className="text-xl font-bold font-mono text-slate-400 mt-0.5">
            {items.filter((i) => i.status === 'Deleted').length}
          </p>
        </div>
      </div>

      {/* Quarantined Inventory Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-xl">
        {items.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <Shield className="w-10 h-10 text-emerald-400 mx-auto" />
            <p className="text-sm font-bold text-white font-mono">Quarantine Vault is Empty</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No isolated threats currently stored. System endpoints are fully protected.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">File Name</th>
                  <th className="p-3.5">Risk Level</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Original File Path</th>
                  <th className="p-3.5">Detection Time</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {items.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="p-3.5 font-bold text-white">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                        <span className="truncate max-w-[180px]">{item.fileName}</span>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.riskLevel === 'CRITICAL' || item.riskLevel === 'HIGH_RISK'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : item.riskLevel === 'SUSPICIOUS'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}
                      >
                        {item.riskLevel}
                      </span>
                    </td>
                    <td className="p-3.5 text-amber-400">{item.category}</td>
                    <td className="p-3.5 text-slate-400 max-w-xs truncate">{item.originalPath}</td>
                    <td className="p-3.5 text-slate-400">{item.detectionTime}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] ${
                          item.status === 'Quarantined'
                            ? 'bg-rose-500/10 text-rose-400'
                            : item.status === 'Restored'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {item.status === 'Quarantined' ? (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedInspectItem(item)}
                            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-400 border border-slate-700"
                            title="View Details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onRestore(item.id)}
                            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-slate-700"
                            title="Restore File"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDelete(item.id)}
                            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-rose-400 border border-slate-700"
                            title="Permanently Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-500 text-[10px]">No Actions</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Inspect Item Modal */}
      {selectedInspectItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl relative">
            <button
              onClick={() => setSelectedInspectItem(null)}
              className="absolute top-4 right-4 p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <ShieldAlert className="w-6 h-6 text-rose-400" />
              <div>
                <h3 className="text-base font-bold text-white font-mono">{selectedInspectItem.fileName}</h3>
                <p className="text-xs text-rose-400 font-mono">
                  Classification: {selectedInspectItem.riskLevel} ({selectedInspectItem.riskScore}/100 Risk)
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">Original Path:</span>
                <span className="text-slate-200 truncate max-w-[240px]">{selectedInspectItem.originalPath}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Threat Category:</span>
                <span className="text-amber-400">{selectedInspectItem.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">File Size:</span>
                <span className="text-slate-200">{selectedInspectItem.size}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">SHA-256 Hash:</span>
                <span className="text-slate-200 truncate max-w-[200px] select-all">{selectedInspectItem.hash}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  onRestore(selectedInspectItem.id);
                  setSelectedInspectItem(null);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 text-xs font-bold font-mono"
              >
                RESTORE FILE
              </button>
              <button
                onClick={() => {
                  onDelete(selectedInspectItem.id);
                  setSelectedInspectItem(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 text-xs font-bold font-mono"
              >
                PERMANENTLY DELETE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
