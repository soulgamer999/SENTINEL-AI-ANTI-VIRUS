import React, { useState } from 'react';
import { Beaker, Award, BookOpen, Play, CheckCircle2, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';

export const SecurityLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'lab' | 'challenge' | 'knowledge'>('lab');

  // Interactive Quiz / Challenge local state
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userScore, setUserScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const quizQuestions = [
    {
      question: 'You receive an email from "accounts-update@paypa1-support.com" requesting immediate password verification. What is the most appropriate action?',
      options: [
        'Click the link and log in immediately to secure the account.',
        'Ignore the email or report it as phishing because of typosquatting domain format.',
        'Reply asking for confirmation from customer support.',
      ],
      correct: 1,
      explanation: 'Typosquatting domains (e.g. paypa1 replacing "l" with "1") are classic indicators of social engineering phishing.',
    },
    {
      question: 'What is the primary indicator of ransomware behavior in system activity?',
      options: [
        'Slow web page loading speeds in Google Chrome.',
        'Rapid, high-entropy mass modification and renaming of document file extensions.',
        'Fan speed increasing during video rendering.',
      ],
      correct: 1,
      explanation: 'Ransomware encrypts target files, resulting in maximum statistical file entropy (randomness) and mass file extension alterations.',
    },
  ];

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    if (idx === quizQuestions[currentQuestion].correct) {
      setUserScore((prev) => prev + 50);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    }
  };

  const mockArticles = [
    { title: 'Understanding File Entropy in Malware Detection', category: 'Analysis', duration: '5 min read' },
    { title: 'How Process Hollowing Bypasses Standard AV Controls', category: 'Defense', duration: '8 min read' },
    { title: 'Demystifying Command-Line Base64 Deobfuscation', category: 'Forensics', duration: '6 min read' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-teal-950 via-slate-900 to-emerald-950 p-6 border border-teal-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-teal-500/20 border border-teal-500/40 text-teal-400">
              <Beaker className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 border border-teal-500/40 text-teal-300 font-mono text-xs font-bold">
                  DEFENSIVE EDUCATION HUB
                </span>
                <span className="font-mono text-xs text-slate-400">Harmless Sandbox Simulations</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Safe Security Lab, Challenges & Knowledge Base</h1>
              <p className="text-xs text-slate-400">
                Explore simulated attack scenarios safely, test defensive instincts in Challenge Mode, and learn core cybersecurity concepts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('lab')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'lab' ? 'bg-teal-500/20 text-teal-400 border border-teal-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Beaker className="w-4 h-4" /> Security Sandbox Lab
            </button>
            <button
              onClick={() => setActiveTab('challenge')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'challenge' ? 'bg-teal-500/20 text-teal-400 border border-teal-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Award className="w-4 h-4" /> Challenge Mode
            </button>
            <button
              onClick={() => setActiveTab('knowledge')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'knowledge' ? 'bg-teal-500/20 text-teal-400 border border-teal-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <BookOpen className="w-4 h-4" /> Knowledge Center
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'lab' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase flex items-center gap-2">
              <Beaker className="w-4 h-4 text-teal-400" /> Interactive Defensive Sandbox
            </h2>
            <p className="text-xs text-slate-400">
              Trigger controlled, harmless simulation models to observe how SentinelAI detects and mitigates threats in real time.
            </p>

            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-white">Simulate High File Entropy Generation</div>
                  <div className="text-[11px] text-slate-400">Demonstrates Ransomware extension detection</div>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-mono text-xs font-bold">
                  Run Model
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-white">Simulate Obfuscated PowerShell Command</div>
                  <div className="text-[11px] text-slate-400">Demonstrates Base64 decoding & process quarantine</div>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-mono text-xs font-bold">
                  Run Model
                </button>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase">Lab Safety Guarantee</h2>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2 text-teal-400 font-mono font-bold">
                <ShieldCheck className="w-4 h-4" /> Inert Test Payloads Only
              </div>
              <p>
                All lab triggers execute harmless synthetic strings or mock event state objects. No actual destructive file modifications or network exploits occur.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'challenge' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-sm font-bold font-mono text-white uppercase">Cyber Defensive Challenge Mode</h2>
              <p className="text-xs text-slate-400">Test your security awareness instincts and earn defensive training badges.</p>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-mono text-slate-400 uppercase">Defensive XP</div>
              <div className="text-xl font-mono font-bold text-teal-400">{userScore} XP</div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-xs font-mono text-slate-400">
              Question {currentQuestion + 1} of {quizQuestions.length}
            </div>
            <h3 className="text-sm font-bold text-white">{quizQuestions[currentQuestion].question}</h3>

            <div className="space-y-2">
              {quizQuestions[currentQuestion].options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={selectedOption !== null}
                  className={`w-full p-3.5 rounded-xl text-left text-xs font-sans transition-all border ${
                    selectedOption === idx
                      ? idx === quizQuestions[currentQuestion].correct
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                        : 'bg-red-500/20 border-red-500 text-red-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>

            {selectedOption !== null && (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 animate-fade-in">
                <p className="text-xs text-slate-300">
                  <span className="font-bold text-teal-400 font-mono">Explanation: </span>
                  {quizQuestions[currentQuestion].explanation}
                </p>

                {currentQuestion < quizQuestions.length - 1 ? (
                  <button
                    onClick={handleNextQuestion}
                    className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-mono text-xs font-bold"
                  >
                    Next Challenge →
                  </button>
                ) : (
                  <div className="text-xs font-mono font-bold text-emerald-400">
                    Challenge Completed! Total XP Earned: {userScore}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'knowledge' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Cybersecurity Knowledge Library</h2>
          <div className="space-y-3">
            {mockArticles.map((art, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{art.title}</div>
                  <div className="font-mono text-[11px] text-slate-400">{art.category} • {art.duration}</div>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 font-mono text-xs">
                  Read Article
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
