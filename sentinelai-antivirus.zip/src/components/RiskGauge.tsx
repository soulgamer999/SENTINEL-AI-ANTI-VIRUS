import React from 'react';
import { ThreatLevel } from '../types';

interface RiskGaugeProps {
  score: number; // 0 - 100
  size?: number;
  label?: string;
  classification?: ThreatLevel;
}

export const getRiskColor = (score: number): {
  color: string;
  strokeColor: string;
  bgColor: string;
  badgeBg: string;
  textColor: string;
  label: ThreatLevel;
} => {
  if (score <= 20) {
    return {
      color: '#10b981', // emerald-500
      strokeColor: '#059669',
      bgColor: 'rgba(16, 185, 129, 0.1)',
      badgeBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      textColor: 'text-emerald-400',
      label: 'SAFE',
    };
  } else if (score <= 40) {
    return {
      color: '#06b6d4', // cyan-500
      strokeColor: '#0891b2',
      bgColor: 'rgba(6, 182, 212, 0.1)',
      badgeBg: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
      textColor: 'text-cyan-400',
      label: 'LOW_RISK',
    };
  } else if (score <= 60) {
    return {
      color: '#f59e0b', // amber-500
      strokeColor: '#d97706',
      bgColor: 'rgba(245, 158, 11, 0.1)',
      badgeBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      textColor: 'text-amber-400',
      label: 'SUSPICIOUS',
    };
  } else if (score <= 80) {
    return {
      color: '#f97316', // orange-500
      strokeColor: '#ea580c',
      bgColor: 'rgba(249, 115, 22, 0.1)',
      badgeBg: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      textColor: 'text-orange-400',
      label: 'HIGH_RISK',
    };
  } else {
    return {
      color: '#f43f5e', // rose-500
      strokeColor: '#e11d48',
      bgColor: 'rgba(244, 63, 94, 0.15)',
      badgeBg: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      textColor: 'text-rose-400',
      label: 'CRITICAL',
    };
  }
};

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  score,
  size = 140,
  label,
  classification,
}) => {
  const info = getRiskColor(score);
  const displayLabel = classification || label || info.label;

  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center relative my-2">
      <div
        className="relative flex items-center justify-center rounded-full p-2 transition-all duration-500"
        style={{ width: size, height: size, backgroundColor: info.bgColor }}
      >
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#1e293b"
            strokeWidth={strokeWidth}
            fill="transparent"
          />
          {/* Risk fill circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={info.color}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-3xl font-extrabold tracking-tight text-white drop-shadow-md">
            {score}
          </span>
          <span className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">
            / 100 RISK
          </span>
        </div>
      </div>
      <div className={`mt-2 px-3 py-0.5 text-xs font-bold uppercase tracking-wider rounded-full border ${info.badgeBg}`}>
        {displayLabel.replace('_', ' ')}
      </div>
    </div>
  );
};
