import React, { useState } from 'react';
import { Award, FileText, Cpu, LineChart, Download, CheckCircle2, ShieldCheck, Sparkles, BarChart2 } from 'lucide-react';

export const GamificationAchievements: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'achievements' | 'reports' | 'performance' | 'evaluation'>('achievements');

  const mockBadges = [
    { title: 'First Quarantine', desc: 'Successfully isolated a suspicious executable.', unlocked: true, date: '2026-03-01' },
    { title: 'Phishing Sentinel', desc: 'Analyzed 5 deceptive email/URL samples.', unlocked: true, date: '2026-03-03' },
    { title: 'SOC Master', desc: 'Maintained 90+ Health Score for 7 consecutive sessions.', unlocked: true, date: '2026-03-05' },
    { title: 'Zero-Trust Guardian', desc: 'Audit developer code for hardcoded secrets.', unlocked: false, progress: '1/3' },
  ];

  const mockReports = [
    { name: 'Weekly System Security & Incident Summary.pdf', date: '2026-03-05', size: '1.2 MB' },
    { name: 'SOC Telemetry & Behavioral Audit Log.csv', date: '2026-03-04', size: '480 KB' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-950 via-slate-900 to-yellow-950 p-6 border border-amber-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
              <Award className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold">
                  REPORTS, METRICS & BADGES
                </span>
                <span className="font-mono text-xs text-slate-400">System Telemetry & Achievements</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Achievements, Automated Reports & Model Evaluation</h1>
              <p className="text-xs text-slate-400">
                View earned security achievements, export PDF/CSV executive reports, and evaluate AI model precision metrics.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('achievements')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'achievements' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Award className="w-4 h-4" /> Achievements
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'reports' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <FileText className="w-4 h-4" /> Reports
            </button>
            <button
              onClick={() => setActiveTab('performance')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'performance' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Cpu className="w-4 h-4" /> Performance
            </button>
            <button
              onClick={() => setActiveTab('evaluation')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'evaluation' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <BarChart2 className="w-4 h-4" /> Model Eval
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'achievements' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {mockBadges.map((badge, idx) => (
            <div
              key={idx}
              className={`p-5 rounded-2xl border space-y-3 ${
                badge.unlocked
                  ? 'bg-slate-900 border-amber-500/40'
                  : 'bg-slate-950/60 border-slate-800/80 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className={`p-2.5 rounded-xl ${badge.unlocked ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-500'}`}>
                  <Award className="w-6 h-6" />
                </div>
                {badge.unlocked ? (
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                    Unlocked
                  </span>
                ) : (
                  <span className="font-mono text-[10px] text-slate-500">{badge.progress}</span>
                )}
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">{badge.title}</h3>
                <p className="text-xs text-slate-400 mt-1">{badge.desc}</p>
              </div>

              {badge.date && <div className="text-[10px] font-mono text-slate-500">Unlocked on {badge.date}</div>}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold font-mono text-white uppercase">Automated Executive Security Reports</h2>
            <button className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-mono text-xs font-bold flex items-center gap-2">
              <Download className="w-4 h-4" /> Generate New Summary PDF
            </button>
          </div>

          <div className="space-y-3">
            {mockReports.map((rep, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{rep.name}</div>
                  <div className="font-mono text-[11px] text-slate-400">{rep.date} • {rep.size}</div>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-amber-300 font-mono text-xs flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5" /> Download
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'performance' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">App Performance & Memory Telemetry</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Scan Pipeline Latency</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">12 ms</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Heap Memory Footprint</div>
              <div className="text-xl font-bold text-cyan-400 mt-1">42.8 MB</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Background Worker Threads</div>
              <div className="text-xl font-bold text-purple-400 mt-1">4 Active</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'evaluation' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">AI Model Accuracy & Confusion Matrix Evaluation</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Accuracy Score</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">98.4%</div>
            </div>
            <div className="text-4 rounded-xl bg-slate-950 border border-slate-800 p-4 text-center">
              <div className="text-xs text-slate-400">Precision</div>
              <div className="text-xl font-bold text-cyan-400 mt-1">97.8%</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Recall Rate</div>
              <div className="text-xl font-bold text-indigo-400 mt-1">99.1%</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
