import React from 'react';
import { BehavioralEvent } from '../types';
import { AlertTriangle, ShieldAlert, X, Cpu, Zap, Activity } from 'lucide-react';

interface AlertCenterOverlayProps {
  alert: BehavioralEvent | null;
  onDismiss: () => void;
  onQuarantineProcess: (evt: BehavioralEvent) => void;
  onInvestigateAi: (evt: BehavioralEvent) => void;
  onEmergencyIsolate?: () => void;
}

export const AlertCenterOverlay: React.FC<AlertCenterOverlayProps> = ({
  alert,
  onDismiss,
  onQuarantineProcess,
  onInvestigateAi,
  onEmergencyIsolate,
}) => {
  if (!alert) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-2xl px-4 animate-bounce-short">
      <div className="relative rounded-2xl bg-slate-900/80 backdrop-blur-2xl border-2 border-red-500/70 p-5 shadow-[0_0_50px_rgba(239,68,68,0.3)] text-slate-100 overflow-hidden">
        {/* Animated background glow pulse */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-red-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-amber-500/20 rounded-full blur-3xl animate-pulse" />

        <div className="flex items-start justify-between gap-4 relative z-10">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-400 shrink-0">
              <ShieldAlert className="w-7 h-7 animate-pulse" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-red-500/30 border border-red-500/50 text-red-300 font-mono text-[10px] font-bold tracking-widest uppercase">
                  HIGH-RISK ALERT
                </span>
                <span className="font-mono text-xs text-slate-400">{alert.timestamp}</span>
              </div>

              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{alert.processName}</span>
                <span className="font-mono text-xs font-normal text-slate-400">(PID: {alert.pid})</span>
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed font-sans">{alert.description}</p>

              <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                <span className="flex items-center gap-1 text-slate-300">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" /> Platform: {alert.platform}
                </span>
                <span className="flex items-center gap-1 text-amber-300">
                  <Zap className="w-3.5 h-3.5" /> Source: {alert.source}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onDismiss}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            title="Dismiss Alert"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Controls */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 relative z-10">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onQuarantineProcess(alert)}
              className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold transition-all shadow-lg shadow-red-900/30 flex items-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5" /> Quarantine Process
            </button>
            <button
              onClick={() => onInvestigateAi(alert)}
              className="px-3 py-1.5 rounded-lg bg-cyan-600/80 hover:bg-cyan-500 text-white font-mono text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Activity className="w-3.5 h-3.5" /> Investigate with Sentinel AI
            </button>
          </div>

          {onEmergencyIsolate && (
            <button
              onClick={onEmergencyIsolate}
              className="px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 font-mono text-xs font-bold transition-all"
            >
              Isolate Endpoint
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
