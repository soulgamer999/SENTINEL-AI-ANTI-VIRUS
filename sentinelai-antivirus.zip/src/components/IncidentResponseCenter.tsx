import React, { useState } from 'react';
import { ShieldAlert, Clock, GitCommit, AlertOctagon, CheckCircle2, Play, ChevronRight, Zap, RefreshCw } from 'lucide-react';

export const IncidentResponseCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'incidents' | 'forensics' | 'graph' | 'emergency'>('incidents');
  const [emergencyActive, setEmergencyActive] = useState(false);

  const mockIncidents = [
    {
      id: 'INC-2026-0891',
      title: 'Ransomware Mass File Rename Attempt',
      timestamp: '14 mins ago',
      severity: 'CRITICAL',
      status: 'Contained',
      summary: 'Process mock_ransomware.exe attempted mass extension modifications on C:\\Users\\Public\\Documents.',
    },
    {
      id: 'INC-2026-0888',
      title: 'Powershell Encrypted Payload Drop',
      timestamp: '2 hours ago',
      severity: 'HIGH',
      status: 'Quarantined',
      summary: 'Powershell script retrieved encoded base64 binary payload from suspicious IP.',
    },
  ];

  const mockForensicsEvents = [
    { time: '14:22:01', source: 'Process Creation', detail: 'Parent process explorer.exe spawned cmd.exe (PID 8492)' },
    { time: '14:22:03', source: 'Network Request', detail: 'Outbound TCP connection to 198.51.100.44:443 established' },
    { time: '14:22:05', source: 'File Modification', detail: 'Attempted modification of host file permissions in System32' },
    { time: '14:22:06', source: 'SentinelAI Action', detail: 'Process PID 8492 suspended and isolated by Behavioral Guard' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Emergency Mode Top Banner if active */}
      {emergencyActive && (
        <div className="rounded-2xl bg-red-950/80 border-2 border-red-500 p-5 animate-pulse flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <AlertOctagon className="w-8 h-8 text-red-400" />
            <div>
              <div className="font-mono font-bold text-sm text-red-300 uppercase">EMERGENCY DEFENSIVE MODE ACTIVE</div>
              <div className="text-xs text-slate-200">Network traffic restricted to local loopback. Automatic process quarantine enforced.</div>
            </div>
          </div>
          <button
            onClick={() => setEmergencyActive(false)}
            className="px-4 py-2 rounded-xl bg-slate-900 border border-red-500/50 text-white font-mono text-xs font-bold hover:bg-slate-800"
          >
            Deactivate Emergency Mode
          </button>
        </div>
      )}

      {/* Main Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 p-6 border border-red-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-400">
              <ShieldAlert className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-red-500/20 border border-red-500/40 text-red-300 font-mono text-xs font-bold">
                  INCIDENT COMMAND CENTER
                </span>
                <span className="font-mono text-xs text-slate-400">SOC Investigation Engine</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Smart Incident Response & Forensics</h1>
              <p className="text-xs text-slate-400">
                Track active security incidents, reconstruct digital forensics timelines, and activate emergency lockdown controls.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('incidents')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'incidents' ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <ShieldAlert className="w-4 h-4" /> Incidents
            </button>
            <button
              onClick={() => setActiveTab('forensics')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'forensics' ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Clock className="w-4 h-4" /> Forensics Timeline
            </button>
            <button
              onClick={() => setActiveTab('graph')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'graph' ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <GitCommit className="w-4 h-4" /> Threat Graph
            </button>
            <button
              onClick={() => setActiveTab('emergency')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'emergency' ? 'bg-red-600 text-white' : 'bg-slate-900 border border-slate-800 text-amber-400'
              }`}
            >
              <AlertOctagon className="w-4 h-4" /> Emergency Mode
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'incidents' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Active Incident Record Files</h2>
          <div className="space-y-3">
            {mockIncidents.map((inc) => (
              <div key={inc.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-red-400">{inc.id}</span>
                    <h3 className="text-xs font-bold text-white">{inc.title}</h3>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                    {inc.status}
                  </span>
                </div>
                <p className="text-xs text-slate-300">{inc.summary}</p>
                <div className="text-[10px] font-mono text-slate-500">Detected: {inc.timestamp}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'forensics' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Reconstructed Forensics Event Timeline</h2>
          <div className="relative border-l-2 border-red-500/40 ml-4 pl-6 space-y-6">
            {mockForensicsEvents.map((ev, idx) => (
              <div key={idx} className="relative">
                <div className="absolute -left-[31px] top-1 w-3 h-3 rounded-full bg-red-500 border-2 border-slate-900" />
                <div className="text-xs font-mono font-bold text-red-400">{ev.time} — {ev.source}</div>
                <p className="text-xs text-slate-300 font-sans mt-0.5">{ev.detail}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'graph' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Threat Relationship Diagram</h2>
          <div className="h-64 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center p-6 text-center">
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-4 text-xs font-mono">
                <span className="p-3 rounded-xl bg-red-950 border border-red-500/50 text-red-300 font-bold">Phishing Link</span>
                <span className="text-slate-500">→</span>
                <span className="p-3 rounded-xl bg-amber-950 border border-amber-500/50 text-amber-300 font-bold">PowerShell Execution</span>
                <span className="text-slate-500">→</span>
                <span className="p-3 rounded-xl bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold">C2 Outbound Ping</span>
              </div>
              <p className="text-xs text-slate-400">Interactive visual chain mapping threat origin to payload delivery and network telemetry.</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'emergency' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase text-red-400 flex items-center gap-2">
            <AlertOctagon className="w-5 h-5" /> Emergency Lockdown Controls
          </h2>
          <p className="text-xs text-slate-400">
            When experiencing a severe malware outbreak or breach, activate Emergency Mode to isolate endpoints, kill unauthorized background processes, and freeze outbound web requests.
          </p>

          <button
            onClick={() => setEmergencyActive(!emergencyActive)}
            className={`w-full py-4 rounded-xl font-mono text-sm font-bold transition-all flex items-center justify-center gap-2 ${
              emergencyActive
                ? 'bg-slate-800 border border-slate-700 text-slate-300'
                : 'bg-red-600 hover:bg-red-500 text-white shadow-xl shadow-red-900/40'
            }`}
          >
            <AlertOctagon className="w-5 h-5" />
            {emergencyActive ? 'Deactivate Emergency Mode' : 'ACTIVATE EMERGENCY LOCKDOWN MODE NOW'}
          </button>
        </div>
      )}
    </div>
  );
};
