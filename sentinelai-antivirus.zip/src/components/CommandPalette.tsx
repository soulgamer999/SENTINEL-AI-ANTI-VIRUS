import React, { useState, useEffect } from 'react';
import {
  Search,
  LayoutDashboard,
  Compass,
  ShieldCheck,
  FileSearch,
  Activity,
  Brain,
  Network,
  Mail,
  KeyRound,
  ShieldAlert,
  Code2,
  Bot,
  Beaker,
  Award,
  Globe,
  Lock,
  BarChart3,
  Settings,
  Flame,
  ArrowRight,
  X,
  Command,
} from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectTab,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const commandItems = [
    { id: 'dashboard', label: 'Security Dashboard', desc: 'Overview, health stats & quick actions', icon: LayoutDashboard, category: 'Core' },
    { id: 'threat_heatmap', label: 'Global Threat Heatmap', desc: 'Real-time simulated global cyber attack visualizer', icon: Flame, category: 'Core' },
    { id: 'landing', label: 'Overview & Mission', desc: 'System capabilities & architecture introduction', icon: Compass, category: 'Core' },
    { id: 'scan', label: 'Real Device & Antivirus Scan', desc: 'Deep memory, local storage & system binary scan', icon: ShieldCheck, category: 'Detection' },
    { id: 'analyzer', label: 'AI File Analyzer', desc: 'Inspect file hashes, Shannon entropy & byte signatures', icon: FileSearch, category: 'Detection' },
    { id: 'behavior', label: 'Behavioral Process Monitor', desc: 'Track PID execution, API calls & process anomalies', icon: Activity, category: 'Detection' },
    { id: 'adaptive_ai', label: 'Adaptive AI Engine', icon: Brain, desc: 'Self-learning threat profile & trust scoring', category: 'AI & Advanced' },
    { id: 'network_map', label: 'Network & Cloud Security Map', desc: 'Live public IP, latency, DNS over HTTPS & topology', icon: Network, category: 'AI & Advanced' },
    { id: 'email_security', label: 'Email & Web Shield', desc: 'Phishing link inspector & email header analyzer', icon: Mail, category: 'AI & Advanced' },
    { id: 'credential_safety', label: 'Credential Safety & Password Health', desc: 'Dark web breach exposure & password strength', icon: KeyRound, category: 'AI & Advanced' },
    { id: 'incident_response', label: 'Incident Response & Forensics', desc: 'Automated containment, memory dumps & isolation', icon: ShieldAlert, category: 'SOC & Forensics' },
    { id: 'devsec_ops', label: 'DevSecOps & Supply Chain Audit', desc: 'Dependency vulnerability auditor & secret scanner', icon: Code2, category: 'SOC & Forensics' },
    { id: 'multi_agent', label: 'Multi-Agent Consensus Engine', desc: 'Sentinel, Vault & NetWatch AI multi-agent voting', icon: Bot, category: 'SOC & Forensics' },
    { id: 'security_lab', label: 'Defensive Cyber Lab', desc: 'Interactive malware sandbox & daily security tips', icon: Beaker, category: 'Labs & Education' },
    { id: 'achievements_reports', label: 'Achievements & Security Reports', desc: 'Gamified badges & PDF executive summary generator', icon: Award, category: 'Labs & Education' },
    { id: 'quarantine', label: 'Quarantine & Intercepted Threats', desc: 'Manage isolated malicious payloads & files', icon: ShieldAlert, category: 'Protection' },
    { id: 'phishing', label: 'Phishing Shield', desc: 'Domain impersonation & SSL certificate validator', icon: Globe, category: 'Protection' },
    { id: 'ransomware', label: 'Ransomware Guard', desc: 'Entropy threshold monitoring & honeyfile canary files', icon: Lock, category: 'Protection' },
    { id: 'analytics', label: 'SOC Intelligence & Analytics', desc: 'Threat classification trends & attack vector metrics', icon: BarChart3, category: 'Intelligence' },
    { id: 'assistant', label: 'Gemini Security Assistant', desc: 'Ask AI conversational security advisor', icon: Bot, category: 'Intelligence' },
    { id: 'settings', label: 'Settings & Performance Diagnostics', desc: 'Configure shields, demo mode & real-time latency diagnostics', icon: Settings, category: 'System' },
  ];

  const filteredItems = commandItems.filter(
    (item) =>
      item.label.toLowerCase().includes(query.toLowerCase()) ||
      item.desc.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) {
          onClose();
        } else {
          setQuery('');
        }
      }

      if (!isOpen) return;

      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredItems.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredItems.length) % Math.max(1, filteredItems.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredItems[selectedIndex]) {
          onSelectTab(filteredItems[selectedIndex].id);
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredItems, selectedIndex, onClose, onSelectTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div
        className="w-full max-w-2xl bg-slate-900 border border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col font-sans"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-800 bg-slate-950/60">
          <Search className="w-5 h-5 text-emerald-400 mr-3 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search SentinelAI sections, tools, or press Esc to exit..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 font-mono outline-none"
          />
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-block px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-400 border border-slate-700">
              ESC
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Results List */}
        <div className="max-h-[380px] overflow-y-auto p-2 space-y-1 scrollbar-thin">
          {filteredItems.length === 0 ? (
            <div className="p-8 text-center text-slate-500 font-mono text-xs">
              No matching security modules found for "{query}".
            </div>
          ) : (
            filteredItems.map((item, index) => {
              const Icon = item.icon;
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-transparent border border-emerald-500/30 text-white'
                      : 'text-slate-300 hover:bg-slate-800/50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-lg ${
                        isSelected ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-emerald-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-100 truncate">{item.label}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono border border-slate-700">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">{item.desc}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0 text-slate-500">
                    {isSelected && <ArrowRight className="w-4 h-4 text-emerald-400 animate-pulse" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Shortcut Navigation Info */}
        <div className="px-4 py-2.5 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">↑↓</kbd> Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">↵</kbd> Select
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Command className="w-3 h-3 text-emerald-400" />
            <span>Power Navigation Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
