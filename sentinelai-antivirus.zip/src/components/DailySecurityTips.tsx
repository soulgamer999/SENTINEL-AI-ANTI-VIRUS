import React, { useState, useEffect } from 'react';
import {
  Lightbulb,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Bot,
  Play,
  Pause,
  Award,
} from 'lucide-react';

interface SecurityTip {
  id: string;
  title: string;
  category: 'High Armor' | 'Hygiene' | 'Urgent Action' | 'DevSecOps';
  summary: string;
  actionableStep: string;
  minScoreTier: 'HIGH' | 'MEDIUM' | 'LOW';
}

interface DailySecurityTipsProps {
  securityScore: number;
  onAskAi: (prompt: string) => void;
}

export const DailySecurityTips: React.FC<DailySecurityTipsProps> = ({
  securityScore,
  onAskAi,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [appliedTips, setAppliedTips] = useState<string[]>([]);
  const [autoPlay, setAutoPlay] = useState(true);

  const tips: SecurityTip[] = [
    {
      id: 'tip-1',
      title: 'Enforce DNS-over-HTTPS (DoH) & Quad9 Filtering',
      category: 'High Armor',
      summary: 'Prevent ISP DNS hijacking and eavesdropping by routing domain lookup queries through encrypted TLS tunnels.',
      actionableStep: 'Enable DNS-over-HTTPS in browser settings or router configuration using 1.1.1.1 or 9.9.9.9.',
      minScoreTier: 'HIGH',
    },
    {
      id: 'tip-2',
      title: 'Audit Hardware Security Key (FIDO2 / YubiKey)',
      category: 'High Armor',
      summary: 'Phishing-resistant authentication prevents credential theft even if your password is stolen or intercepted.',
      actionableStep: 'Register a FIDO2 hardware token for primary email and password manager accounts.',
      minScoreTier: 'HIGH',
    },
    {
      id: 'tip-3',
      title: 'Verify SPF, DKIM, and DMARC Headers on Suspicious Emails',
      category: 'Hygiene',
      summary: 'Domain spoofing is used in 80%+ of spear-phishing attacks. Check raw email headers before trusting links.',
      actionableStep: 'Look for "Authentication-Results: dmarc=pass" in message details before clicking links.',
      minScoreTier: 'MEDIUM',
    },
    {
      id: 'tip-4',
      title: 'Disable Legacy SMBv1 & Unencrypted File Shares',
      category: 'Hygiene',
      summary: 'Legacy SMB protocols are infamous entry points for wormable ransomware strains like EternalBlue.',
      actionableStep: 'Open Windows Features or Terminal and run "Disable-WindowsOptionalFeature -FeatureName SMB1Protocol".',
      minScoreTier: 'MEDIUM',
    },
    {
      id: 'tip-5',
      title: 'Urgent: Rotate Reused Passwords & Enable Password Manager',
      category: 'Urgent Action',
      summary: 'Credential stuffing bots exploit leaked password databases across multiple consumer sites.',
      actionableStep: 'Use a zero-knowledge password manager to generate unique 20+ character passwords for every login.',
      minScoreTier: 'LOW',
    },
    {
      id: 'tip-6',
      title: 'Isolate & Quarantine High-Entropy Files',
      category: 'Urgent Action',
      summary: 'Files with Shannon entropy > 7.2 are frequently packed or encrypted malware payloads.',
      actionableStep: 'Run a deep scan or isolate suspicious attachments using the SentinelAI Quarantine Center.',
      minScoreTier: 'LOW',
    },
  ];

  // Filter tips appropriate for current security health score
  const userTier = securityScore >= 85 ? 'HIGH' : securityScore >= 65 ? 'MEDIUM' : 'LOW';
  const relevantTips = tips.filter((t) => {
    if (userTier === 'LOW') return true;
    if (userTier === 'MEDIUM') return t.minScoreTier === 'MEDIUM' || t.minScoreTier === 'HIGH';
    return t.minScoreTier === 'HIGH' || t.minScoreTier === 'MEDIUM';
  });

  // Auto-play timer
  useEffect(() => {
    if (!autoPlay || relevantTips.length === 0) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % relevantTips.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [autoPlay, relevantTips.length]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % relevantTips.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + relevantTips.length) % relevantTips.length);
  };

  const handleMarkApplied = (tipId: string) => {
    if (!appliedTips.includes(tipId)) {
      setAppliedTips((prev) => [...prev, tipId]);
    }
  };

  const currentTip = relevantTips[currentIndex] || tips[0];
  const isApplied = appliedTips.includes(currentTip.id);

  return (
    <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-950 border border-slate-800 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <Lightbulb className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider">
              Daily Security Intelligence Tip
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">
              Tailored for Health Score Tier: <strong className="text-emerald-400">{userTier} ({securityScore}/100)</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoPlay(!autoPlay)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            title={autoPlay ? 'Pause Auto-Cycle' : 'Play Auto-Cycle'}
          >
            {autoPlay ? <Pause className="w-3.5 h-3.5 text-emerald-400" /> : <Play className="w-3.5 h-3.5 text-slate-500" />}
          </button>
          <div className="flex items-center gap-1 font-mono text-xs text-slate-400">
            <span>{currentIndex + 1}</span> / <span>{relevantTips.length}</span>
          </div>
        </div>
      </div>

      {/* Tip Card Body */}
      <div className="space-y-3 font-sans">
        <div className="flex items-center justify-between">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            {currentTip.category}
          </span>
          {isApplied && (
            <span className="flex items-center gap-1 text-[11px] font-mono font-bold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" /> Applied (+5 Health Bonus)
            </span>
          )}
        </div>

        <h4 className="text-sm font-bold text-white font-mono">{currentTip.title}</h4>
        <p className="text-xs text-slate-300 leading-relaxed">{currentTip.summary}</p>

        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1">
          <span className="text-slate-500 text-[10px] uppercase font-bold block">Recommended Action:</span>
          <p className="text-emerald-300">{currentTip.actionableStep}</p>
        </div>
      </div>

      {/* Actions & Navigation Controls */}
      <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleMarkApplied(currentTip.id)}
            disabled={isApplied}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
              isApplied
                ? 'bg-slate-900 text-slate-500 border border-slate-800'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            {isApplied ? 'Applied' : 'Mark as Applied'}
          </button>

          <button
            onClick={() =>
              onAskAi(`Can you explain more about "${currentTip.title}" and how I can implement it in SentinelAI?`)
            }
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-mono flex items-center gap-1.5 transition-all"
          >
            <Bot className="w-3.5 h-3.5" /> Ask Gemini AI
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handlePrev}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleNext}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
