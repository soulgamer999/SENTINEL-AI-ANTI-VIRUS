import React, { useState } from 'react';
import { Code2, Box, Sparkles, Send, AlertTriangle, ShieldCheck, RefreshCw, FileCode2 } from 'lucide-react';

export const DeveloperSecurityMode: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'audit' | 'supply'>('audit');

  const [codeSnippet, setCodeSnippet] = useState(
    `// Example server configuration
const express = require('express');
const app = express();

const API_SECRET_KEY = "sk_live_9843209840298342309482"; // Hardcoded secret
const DATABASE_URL = "postgres://admin:password123@localhost:5432/production";

app.get('/user', (req, res) => {
  const query = "SELECT * FROM users WHERE id = " + req.query.id; // Unsafe SQL concatenation
  db.query(query);
});`
  );

  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<any>(null);

  const mockDependencies = [
    { name: 'express', version: '4.21.2', status: 'Secure', cve: 'None' },
    { name: '@google/genai', version: '2.4.0', status: 'Secure', cve: 'None' },
    { name: 'sample-vulnerable-package', version: '1.0.2', status: 'Vulnerable', cve: 'CVE-2025-1192', severity: 'HIGH', fix: 'Upgrade to 1.0.3+' },
  ];

  const handleAuditCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuditing(true);
    setAuditResult(null);

    try {
      const res = await fetch('/api/audit-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ codeOrConfig: codeSnippet, fileType: 'javascript' }),
      });
      const data = await res.json();
      setAuditResult(data);
    } catch (err) {
      console.error('Audit code error', err);
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 p-6 border border-blue-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-blue-500/20 border border-blue-500/40 text-blue-400">
              <Code2 className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-500/40 text-blue-300 font-mono text-xs font-bold">
                  DEVSEC OPS HUB
                </span>
                <span className="font-mono text-xs text-slate-400">Code & Dependency Audit</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Developer Security & Supply-Chain Monitor</h1>
              <p className="text-xs text-slate-400">
                Audit source code for secrets/vulnerabilities and track third-party library dependency CVE risks.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'audit' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Code2 className="w-4 h-4" /> Code Auditor
            </button>
            <button
              onClick={() => setActiveTab('supply')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'supply' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Box className="w-4 h-4" /> Supply Chain Monitor
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'audit' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-blue-400" /> Source Code & Config Inspector
            </h2>

            <form onSubmit={handleAuditCode} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Code / Configuration Snippet</label>
                <textarea
                  rows={8}
                  value={codeSnippet}
                  onChange={(e) => setCodeSnippet(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-blue-300 font-mono focus:border-blue-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isAuditing}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-mono text-xs font-bold transition-all shadow-lg shadow-blue-900/30 flex items-center justify-center gap-2"
              >
                {isAuditing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Scanning with Gemini DevSec Auditor...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" /> Audit Code Security
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase">Security Audit Findings</h2>

            {auditResult ? (
              <div className="space-y-4 animate-fade-in">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-mono text-slate-400 uppercase">Code Risk Score</div>
                    <div
                      className={`text-2xl font-mono font-bold ${
                        auditResult.riskScore > 50 ? 'text-red-400' : 'text-emerald-400'
                      }`}
                    >
                      {auditResult.riskScore} / 100
                    </div>
                  </div>
                  <span className="text-xs font-mono text-slate-300 max-w-xs text-right">{auditResult.overallVerdict}</span>
                </div>

                <div className="space-y-3">
                  {auditResult.findings?.map((item: any, idx: number) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{item.issue}</span>
                        <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-mono text-[10px] font-bold">
                          {item.severity}
                        </span>
                      </div>
                      <p className="text-slate-300">{item.explanation}</p>
                      <div className="p-2 rounded bg-slate-900 border border-slate-800 text-emerald-400 font-mono text-[11px]">
                        Fix: {item.remediation}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-64 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-center p-6 text-slate-500 font-mono text-xs">
                Submit a code snippet to run static vulnerability analysis and hardcoded secret detection.
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'supply' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Software Supply-Chain & Package Monitor</h2>
          <div className="space-y-3">
            {mockDependencies.map((dep, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold font-mono text-white">{dep.name} <span className="text-slate-400 font-normal">({dep.version})</span></div>
                  {dep.fix && <div className="text-[11px] text-amber-400 font-mono mt-0.5">{dep.fix}</div>}
                </div>
                <div>
                  <span
                    className={`px-2.5 py-1 rounded font-mono text-[10px] font-bold ${
                      dep.status === 'Secure' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                    }`}
                  >
                    {dep.status} ({dep.cve})
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
