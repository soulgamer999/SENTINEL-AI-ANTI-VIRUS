import React from 'react';
import {
  ShieldCheck,
  Zap,
  Lock,
  Globe,
  Bot,
  Activity,
  Play,
  FileSearch,
  LayoutDashboard,
  Monitor,
  Smartphone,
  ChevronRight,
  CheckCircle2,
  Cpu,
  Sparkles,
} from 'lucide-react';

interface LandingPageProps {
  onStartScan: () => void;
  onAnalyzeFile: () => void;
  onOpenDashboard: () => void;
  onToggleDemoMode: () => void;
  demoMode: boolean;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartScan,
  onAnalyzeFile,
  onOpenDashboard,
  onToggleDemoMode,
  demoMode,
}) => {
  const featureCards = [
    {
      title: 'AI Threat Detection',
      description: 'Combines heuristic rules with deep neural features to score code entropy, section anomalies, and malware characteristics.',
      icon: Zap,
      color: 'from-emerald-500/20 to-teal-500/5',
      borderColor: 'border-emerald-500/30',
      iconColor: 'text-emerald-400',
    },
    {
      title: 'Behavior Analysis',
      description: 'Monitors real-time process execution, registry edits, shadow copy access, and outbound socket connections for anomalies.',
      icon: Activity,
      color: 'from-cyan-500/20 to-blue-500/5',
      borderColor: 'border-cyan-500/30',
      iconColor: 'text-cyan-400',
    },
    {
      title: 'Ransomware Protection',
      description: 'Intercepts high-volume rapid file modifications in real time, immediately suspending suspect PIDs and isolating sensitive user directories.',
      icon: Lock,
      color: 'from-purple-500/20 to-pink-500/5',
      borderColor: 'border-purple-500/30',
      iconColor: 'text-purple-400',
    },
    {
      title: 'Phishing Detection',
      description: 'Analyzes suspicious URLs and email messages for domain typosquatting, brand spoofing, and credential harvesting prompts.',
      icon: Globe,
      color: 'from-amber-500/20 to-yellow-500/5',
      borderColor: 'border-amber-500/30',
      iconColor: 'text-amber-400',
    },
    {
      title: 'AI Security Assistant',
      description: 'Powered by Gemini 3.6 to explain threat flags in plain language, breakdown code risk factors, and provide defensive guidance.',
      icon: Bot,
      color: 'from-blue-500/20 to-indigo-500/5',
      borderColor: 'border-blue-500/30',
      iconColor: 'text-blue-400',
    },
    {
      title: 'Real-Time Monitoring',
      description: 'Continuous cross-platform endpoint shield running quietly across Windows, macOS, Linux, Android, and iOS environments.',
      icon: ShieldCheck,
      color: 'from-rose-500/20 to-red-500/5',
      borderColor: 'border-rose-500/30',
      iconColor: 'text-rose-400',
    },
  ];

  return (
    <div className="space-y-12 py-4">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-slate-800 p-8 lg:p-12 text-center shadow-2xl">
        {/* Glowing Background Radial */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-emerald-400 font-mono font-medium">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>AI-POWERED CYBERSECURITY PLATFORM</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight uppercase font-mono">
            SENTINEL<span className="text-emerald-400">AI</span>
          </h1>

          <p className="text-xl sm:text-2xl font-bold text-slate-300 tracking-wide font-sans italic">
            “Detect. Understand. Protect.”
          </p>

          <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Next-generation endpoint security combining machine learning feature extraction, behavior monitoring, ransomware defense, and Gemini AI threat explanation.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={onStartScan}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" /> START SCAN
            </button>

            <button
              onClick={onAnalyzeFile}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-sm transition-all active:scale-95"
            >
              <FileSearch className="w-4 h-4 text-cyan-400" /> ANALYZE FILE
            </button>

            <button
              onClick={onOpenDashboard}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-bold text-sm transition-all active:scale-95"
            >
              <LayoutDashboard className="w-4 h-4 text-purple-400" /> OPEN SECURITY CENTER
            </button>
          </div>

          {/* Demo Mode Banner Callout */}
          <div className="pt-6">
            <div
              onClick={onToggleDemoMode}
              className={`inline-flex items-center gap-3 px-4 py-2 rounded-2xl border text-xs cursor-pointer transition-all ${
                demoMode
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
              <span>
                Hackathon Demo Mode is <strong className="font-mono">{demoMode ? 'ACTIVE' : 'OFF'}</strong>. Click to toggle harmless test payloads & simulations.
              </span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Cross Platform Support Highlight */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
              <Cpu className="w-5 h-5 text-emerald-400" /> Multi-Platform Universal Deployment
            </h3>
            <p className="text-xs text-slate-400">
              Native agent fleet designed to protect all your endpoints simultaneously.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {['Windows 11', 'macOS Sonoma', 'Linux (Ubuntu/RHEL)', 'Android 14', 'iOS 18'].map((platform) => (
              <span
                key={platform}
                className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400 font-mono flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> {platform}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div className="space-y-4">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h2 className="text-xl font-bold text-white font-mono">Core Protection Modules</h2>
          <p className="text-xs text-slate-400">
            Powered by modern machine learning, behavior heuristics, and Gemini AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {featureCards.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className={`p-5 rounded-2xl bg-gradient-to-br ${feat.color} border ${feat.borderColor} space-y-3 transition-all hover:scale-[1.01]`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl bg-slate-950 border border-slate-800 ${feat.iconColor}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-white font-mono">{feat.title}</h3>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{feat.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Philosophical Paradigm Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-500/30 text-center space-y-3">
        <p className="text-xs uppercase tracking-widest text-emerald-400 font-mono font-bold">
          The SentinelAI Paradigm
        </p>
        <blockquote className="text-lg font-bold text-slate-200 italic max-w-2xl mx-auto">
          “Traditional antivirus asks: <span className="text-slate-400">‘Have I seen this threat before?’</span>
          <br />
          SentinelAI asks: <span className="text-emerald-400">‘Does this behavior look dangerous?’</span>”
        </blockquote>
      </div>
    </div>
  );
};
