import React, { useState } from 'react';
import { KeyRound, ShieldCheck, Lock, Eye, EyeOff, ShieldAlert, Sparkles, CheckCircle2, AlertTriangle, UserCheck } from 'lucide-react';

export const CredentialSafetyCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'credentials' | 'health' | 'privacy'>('credentials');

  // Password checker local state
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const calculatePasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: 'Empty', color: 'text-slate-500' };
    let score = 0;
    if (pass.length >= 8) score += 25;
    if (pass.length >= 12) score += 25;
    if (/[A-Z]/.test(pass)) score += 15;
    if (/[0-9]/.test(pass)) score += 15;
    if (/[^A-Za-z0-9]/.test(pass)) score += 20;

    if (score < 40) return { score, label: 'Weak (Vulnerable to brute force)', color: 'text-red-400' };
    if (score < 75) return { score, label: 'Moderate (Acceptable for non-critical accounts)', color: 'text-amber-400' };
    return { score, label: 'Strong (High Resistance)', color: 'text-emerald-400' };
  };

  const strength = calculatePasswordStrength(passwordInput);

  const mockHealthMetrics = [
    { name: 'Endpoint Protection Agent Status', status: 'Active (v3.6)', score: 100, impact: 'High' },
    { name: 'Real-time File & Process Scan', status: 'Enabled', score: 95, impact: 'High' },
    { name: 'Browser Phishing Filter', status: 'Enabled', score: 90, impact: 'Medium' },
    { name: 'Password Reuse Audit', status: '2 Weak Passwords', score: 65, impact: 'Medium' },
    { name: 'Two-Factor Authentication (2FA)', status: 'Enforced', score: 100, impact: 'High' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 p-6 border border-emerald-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
              <KeyRound className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold">
                  IDENTITY & HEALTH HUB
                </span>
                <span className="font-mono text-xs text-slate-400">Zero Local Transmission</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Credential Safety, Health Score & Privacy</h1>
              <p className="text-xs text-slate-400">
                Audit credential strength locally, evaluate overall system posture score (0-100), and inspect privacy permissions.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('credentials')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'credentials' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <KeyRound className="w-4 h-4" /> Credential Safety
            </button>
            <button
              onClick={() => setActiveTab('health')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'health' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <ShieldCheck className="w-4 h-4" /> Health Score (92)
            </button>
            <button
              onClick={() => setActiveTab('privacy')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'privacy' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Lock className="w-4 h-4" /> Privacy Center
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'credentials' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold font-mono text-white uppercase">Local Password & Secret Strength Auditor</h2>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[10px]">100% Client-Side</span>
            </div>

            <p className="text-xs text-slate-400">
              Test passwords or API tokens locally. Your input is evaluated strictly in-browser and is never sent across any network.
            </p>

            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-sm font-mono text-white focus:border-emerald-500 focus:outline-none pr-12"
                placeholder="Type a password to test..."
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {passwordInput && (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 animate-fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-400">Entropy Score</span>
                  <span className={`text-xs font-mono font-bold ${strength.color}`}>{strength.score} / 100 ({strength.label})</span>
                </div>

                <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      strength.score < 40 ? 'bg-red-500' : strength.score < 75 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${strength.score}%` }}
                  />
                </div>

                <ul className="text-[11px] font-mono text-slate-400 space-y-1 pt-1">
                  <li className={passwordInput.length >= 12 ? 'text-emerald-400' : 'text-slate-500'}>
                    ✓ At least 12 characters long
                  </li>
                  <li className={/[A-Z]/.test(passwordInput) ? 'text-emerald-400' : 'text-slate-500'}>
                    ✓ Includes uppercase letter
                  </li>
                  <li className={/[0-9]/.test(passwordInput) ? 'text-emerald-400' : 'text-slate-500'}>
                    ✓ Includes numerical digits
                  </li>
                  <li className={/[^A-Za-z0-9]/.test(passwordInput) ? 'text-emerald-400' : 'text-slate-500'}>
                    ✓ Includes special symbols (!@#$)
                  </li>
                </ul>
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-sm font-bold font-mono text-white uppercase">Breach Exposure Check</h2>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs text-slate-300">
              <div className="flex items-center justify-between text-emerald-400 font-mono font-bold">
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4" /> Zero Compromised Hashes</span>
                <span>Active Shield</span>
              </div>
              <p>
                SentinelAI checks local database hashes against synthetic known leaked database dumps to warn you if credentials match historical public leaks.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'health' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold font-mono text-white uppercase">System Health Score Breakdown</h2>
              <p className="text-xs text-slate-400">Comprehensive security score metric derived from active defensive modules.</p>
            </div>
            <div className="text-3xl font-mono font-bold text-emerald-400">92 <span className="text-xs text-slate-500 font-normal">/ 100</span></div>
          </div>

          <div className="space-y-2">
            {mockHealthMetrics.map((item, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{item.name}</div>
                  <div className="font-mono text-[11px] text-slate-400">Status: {item.status}</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-emerald-400">{item.score}%</div>
                  <div className="text-[10px] font-mono text-slate-500">Impact: {item.impact}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'privacy' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">SentinelAI Privacy Center</h2>
          <p className="text-xs text-slate-400">
            Explicit transparency rules regarding telemetry, file analysis, and data isolation.
          </p>

          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-white">Zero File Execution On Server</div>
                <div className="text-slate-400 mt-0.5">Uploaded files are analyzed for metadata, entropy, and structure without execution.</div>
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-white">Local-First Storage</div>
                <div className="text-slate-400 mt-0.5">Quarantined files, logs, and settings remain isolated in your browser or dev environment.</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
