import React from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  FileCheck2,
  AlertTriangle,
  Lock,
  Play,
  FileSearch,
  Activity,
  Bot,
  Monitor,
  Smartphone,
  Server,
  Globe,
  Radio,
  Clock,
  ChevronRight,
  Sparkles,
  Flame,
} from 'lucide-react';
import { SystemSecurityStats, PlatformStatus, BehavioralEvent } from '../types';
import { RiskGauge } from './RiskGauge';
import { DailySecurityTips } from './DailySecurityTips';

interface DashboardProps {
  stats: SystemSecurityStats;
  platforms: PlatformStatus[];
  recentEvents: BehavioralEvent[];
  onSelectTab: (tab: string) => void;
  onQuickScan: () => void;
  demoMode: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({
  stats,
  platforms,
  recentEvents,
  onSelectTab,
  onQuickScan,
  demoMode,
}) => {
  return (
    <div className="space-y-6 py-2">
      {/* Top Banner: Status + Overall Score */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Main Status Hero */}
        <div className="lg:col-span-3 p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-950 border border-slate-800 relative overflow-hidden flex flex-col justify-between shadow-xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
                  SYSTEM STATUS
                </span>
                {demoMode && (
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-md">
                    DEMO MODE ACTIVE
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
                PROTECTED & ACTIVE
              </h1>
              <p className="text-xs text-slate-400">
                Multi-layer real-time behavioral shield and Gemini AI heuristic engine operational.
              </p>
            </div>

            <button
              onClick={onQuickScan}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-emerald-500/20 active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" /> RUN QUICK SCAN
            </button>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 mt-4 border-t border-slate-800/80">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono text-slate-400">Files Scanned</span>
              <p className="text-lg font-bold font-mono text-white mt-0.5">
                {stats.filesScanned.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono text-slate-400">Threats Intercepted</span>
              <p className="text-lg font-bold font-mono text-rose-400 mt-0.5">
                {stats.threatsDetected}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono text-slate-400">Suspicious Events</span>
              <p className="text-lg font-bold font-mono text-amber-400 mt-0.5">
                {stats.suspiciousCount}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono text-slate-400">Quarantined Items</span>
              <p className="text-lg font-bold font-mono text-cyan-400 mt-0.5">
                {stats.quarantinedCount}
              </p>
            </div>
          </div>
        </div>

        {/* Security Score Gauge Card */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center justify-center text-center shadow-xl">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            OVERALL SECURITY SCORE
          </span>
          <RiskGauge score={stats.securityScore} size={130} label="PROTECTED" />
          <p className="text-[11px] text-slate-400 mt-1">
            Zero critical vulnerabilities detected in active endpoint memory.
          </p>
        </div>
      </div>

      {/* Daily Security Tips Carousel Carousel Box */}
      <DailySecurityTips
        securityScore={stats.securityScore}
        onAskAi={(prompt) => {
          onSelectTab('assistant');
        }}
      />

      {/* Futuristic Cyber Threat Map & SOC Visualizer */}
      <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 relative overflow-hidden space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Global Cyber Threat Radar & Endpoint Telemetry Map
            </h2>
          </div>
          <button
            onClick={() => onSelectTab('threat_heatmap')}
            className="flex items-center gap-1.5 text-[11px] font-mono text-rose-400 hover:text-rose-300 bg-rose-500/10 px-3 py-1 rounded-md border border-rose-500/30 transition-all"
          >
            <Flame className="w-3.5 h-3.5" /> OPEN FULL THREAT HEATMAP <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Simulated Animated Radar Map Canvas Box */}
        <div className="relative h-48 w-full rounded-xl bg-slate-900/80 border border-slate-800 overflow-hidden flex items-center justify-center">
          {/* Radial Grid lines */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
            <div className="w-96 h-96 rounded-full border border-emerald-500" />
            <div className="w-64 h-64 rounded-full border border-emerald-500 absolute" />
            <div className="w-32 h-32 rounded-full border border-emerald-500 absolute" />
            <div className="w-full h-px bg-emerald-500 absolute" />
            <div className="h-full w-px bg-emerald-500 absolute" />
          </div>

          {/* Sweeping Radar Scanner Bar */}
          <div className="absolute w-1/2 h-1/2 bg-gradient-to-tr from-emerald-500/20 to-transparent origin-bottom-right animate-spin top-0 left-0 pointer-events-none" style={{ animationDuration: '8s' }} />

          {/* Node Threat Ping Points */}
          <div className="absolute top-10 left-20 flex items-center gap-1 bg-slate-950/90 px-2 py-0.5 rounded border border-rose-500/40 text-[10px] text-rose-400 font-mono shadow-lg">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span>US-East: Ransomware Blocked</span>
          </div>

          <div className="absolute bottom-8 right-24 flex items-center gap-1 bg-slate-950/90 px-2 py-0.5 rounded border border-emerald-500/40 text-[10px] text-emerald-400 font-mono shadow-lg">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>EU-Central: Shield Sync</span>
          </div>

          <div className="absolute top-12 right-1/3 flex items-center gap-1 bg-slate-950/90 px-2 py-0.5 rounded border border-amber-500/40 text-[10px] text-amber-400 font-mono shadow-lg">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span>Asia-Pacific: Port Probe Filtered</span>
          </div>

          <div className="z-10 text-center space-y-1 bg-slate-950/80 p-3 rounded-xl border border-slate-800 backdrop-blur-md">
            <p className="text-xs font-mono font-bold text-white">ACTIVE ENDPOINT TELEMETRY HUB</p>
            <p className="text-[11px] text-slate-400">
              5 Agent Clusters • Zero Latency Behavioral Intercepts
            </p>
          </div>
        </div>
      </div>

      {/* Multi-Platform Agent Fleet Status */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Monitor className="w-4 h-4 text-cyan-400" /> Multi-Platform Endpoint Protection Fleet
          </h2>
          <span className="text-xs text-slate-400">All Agents Synchronized</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {platforms.map((p) => (
            <div
              key={p.platform}
              className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white font-mono flex items-center gap-1.5">
                  {p.platform === 'Android' || p.platform === 'iOS' ? (
                    <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                  ) : (
                    <Monitor className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  {p.platform}
                </span>
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
              </div>

              <div className="text-[11px] space-y-1 text-slate-400">
                <div className="flex justify-between">
                  <span>Agent:</span>
                  <span className="font-mono text-slate-300">{p.agentVersion}</span>
                </div>
                <div className="flex justify-between">
                  <span>Scanned:</span>
                  <span className="font-mono text-slate-300">{p.filesScanned}</span>
                </div>
                <div className="flex justify-between">
                  <span>Blocked:</span>
                  <span className="font-mono text-emerald-400 font-bold">{p.threatsBlocked}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Row: Recent Events & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent Security Events */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" /> Recent Security Events
            </h3>
            <button
              onClick={() => onSelectTab('behavior')}
              className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              View Behavior Log <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2">
            {recentEvents.slice(0, 4).map((evt) => (
              <div
                key={evt.id}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        evt.type === 'HIGH_RISK'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : evt.type === 'SUSPICIOUS'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {evt.type}
                    </span>
                    <span className="font-mono text-slate-300 font-semibold">{evt.processName}</span>
                    <span className="text-[10px] text-slate-500 font-mono">(PID: {evt.pid})</span>
                  </div>
                  <p className="text-slate-400 leading-normal">{evt.description}</p>
                </div>
                <span className="text-[10px] text-slate-500 font-mono whitespace-nowrap">{evt.timestamp}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Operations Shortcuts */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
              Operations Center Shortcuts
            </h3>

            <div className="space-y-2">
              <button
                onClick={() => onSelectTab('analyzer')}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-xs transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <FileSearch className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <div>
                    <span className="font-bold text-white block">AI File Analyzer</span>
                    <span className="text-[10px] text-slate-400">Deep HEURISTIC & SHA-256 analysis</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>

              <button
                onClick={() => onSelectTab('ransomware')}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-purple-500/30 hover:border-purple-500/60 text-left text-xs transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <Lock className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
                  <div>
                    <span className="font-bold text-white block">Ransomware Guard Simulation</span>
                    <span className="text-[10px] text-purple-300">Test rapid file modification intercept</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-purple-400" />
              </button>

              <button
                onClick={() => onSelectTab('assistant')}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-xs transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <Bot className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <div>
                    <span className="font-bold text-white block">Sentinel AI Chatbot</span>
                    <span className="text-[10px] text-slate-400">Ask why a file was flagged</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Gemini 3.6 AI Defense Engine active for explanations & phishing evaluation.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
