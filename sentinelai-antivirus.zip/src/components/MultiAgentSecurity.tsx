import React, { useState } from 'react';
import { Bot, Brain, Shield, Sparkles, User, Layers, Search, CheckCircle2 } from 'lucide-react';

export const MultiAgentSecurity: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'agents' | 'explainable'>('agents');

  const mockAgents = [
    { role: 'Threat Intelligence Agent', focus: 'Malware Hashes & Global Feeds', status: 'Active', opinion: 'Hash corresponds to unknown target packer, warrants entropy inspection.' },
    { role: 'Behavioral Monitoring Agent', focus: 'System Call Patterns', status: 'Active', opinion: 'Observed process requesting direct registry key modification.' },
    { role: 'Phishing & Email Agent', focus: 'NLP & Urgency Language', status: 'Active', opinion: 'Grammatical analysis indicates severe psychological manipulation.' },
    { role: 'Risk Scoring Agent', focus: 'Composite Risk Indexing', status: 'Active', opinion: 'Aggregated risk score computed as 88/100 (HIGH RISK).' },
    { role: 'Advisory AI Agent', focus: 'Remediation Steps', status: 'Active', opinion: 'Recommend immediate quarantine and process termination.' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-cyan-950 p-6 border border-emerald-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
              <Bot className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold">
                  SPECIALIZED AI CONCENSUS
                </span>
                <span className="font-mono text-xs text-slate-400">5 Autonomous Agents</span>
              </div>
              <h1 className="text-xl font-bold text-white mt-1">Multi-Agent Security Analysis & Explainable AI</h1>
              <p className="text-xs text-slate-400">
                Five internal AI roles cross-examine threat indicators to produce transparent, explainable consensus reports.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('agents')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'agents' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Bot className="w-4 h-4" /> Multi-Agent Consensus
            </button>
            <button
              onClick={() => setActiveTab('explainable')}
              className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'explainable' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-900 border border-slate-800 text-slate-400'
              }`}
            >
              <Search className="w-4 h-4" /> Explainable AI Panel
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'agents' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockAgents.map((ag, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Bot className="w-5 h-5" />
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                  {ag.status}
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">{ag.role}</h3>
                <div className="text-[11px] font-mono text-slate-400">Focus: {ag.focus}</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 font-sans">
                "{ag.opinion}"
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'explainable' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h2 className="text-sm font-bold font-mono text-white uppercase">Explainable AI Transparency Metrics</h2>
          <p className="text-xs text-slate-400">
            SentinelAI displays the exact decision weights used by the model to prevent black-box decision uncertainty.
          </p>

          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">File Entropy & Packing Factor</span>
                <span className="text-emerald-400 font-bold">Weight: 35%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-emerald-400 w-[35%]" />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Behavioral Registry & System Call Activity</span>
                <span className="text-cyan-400 font-bold">Weight: 40%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-cyan-400 w-[40%]" />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Reputation & IOC Threat Memory Match</span>
                <span className="text-purple-400 font-bold">Weight: 25%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-purple-400 w-[25%]" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
