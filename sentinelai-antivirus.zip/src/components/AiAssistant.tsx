import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Shield,
  HelpCircle,
  Loader2,
  User,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import { ChatMessage } from '../types';

export const AiAssistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      sender: 'assistant',
      text: 'Hello! I am Sentinel AI Assistant, your defensive cybersecurity advisor. How can I help you understand flagged threats, ransomware defense, or endpoint security today?',
      timestamp: 'Just now',
    },
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const samplePrompts = [
    'Why was Invoice_Payment_Update.exe flagged?',
    'How does ransomware protection work?',
    'What is a phishing attack and how do I spot it?',
    'What should I do if a file is classified as suspicious?',
    'How can I improve my overall security score to 100/100?',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMsg;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMsg('');
    setLoading(true);

    try {
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'I am ready to assist with your defensive cybersecurity questions.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const fallbackMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: 'Sentinel AI Assistant: Here is the defensive overview regarding your query:\n\n• **Heuristic Safety**: Always inspect file SHA-256 signatures, verify publisher digital certificates, and isolate unknown binaries in Quarantine.\n• **Ransomware Protection**: SentinelAI monitors mass file modification rates and shadow copy access in real-time.\n• **Security Best Practice**: Keep endpoint software updated and exercise caution with unexpected email attachments.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Bot className="w-6 h-6 text-emerald-400" /> SENTINEL AI SECURITY ASSISTANT
          </h1>
          <p className="text-xs text-slate-400">
            Powered by Gemini 3.6 to provide defensive cybersecurity guidance, threat breakdowns, and security score optimizations.
          </p>
        </div>
      </div>

      {/* Suggested Prompt Chips */}
      <div className="space-y-2">
        <span className="text-[11px] font-mono font-bold text-slate-400 uppercase block">
          Suggested Security Inquiries:
        </span>
        <div className="flex flex-wrap gap-2 text-xs">
          {samplePrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-slate-300 font-mono text-[11px] transition-all"
            >
              💬 {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Window Container */}
      <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between h-[520px] shadow-2xl space-y-4">
        {/* Messages Stream */}
        <div className="overflow-y-auto space-y-4 pr-2">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${
                m.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {m.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-4 rounded-2xl max-w-2xl text-xs leading-relaxed space-y-1 font-sans ${
                  m.sender === 'user'
                    ? 'bg-emerald-500 text-slate-950 font-semibold font-mono rounded-tr-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] opacity-70 mb-1">
                  <span>{m.sender === 'user' ? 'You' : 'Sentinel AI Assistant'}</span>
                  <span>{m.timestamp}</span>
                </div>
                <p className="whitespace-pre-wrap">{m.text}</p>
              </div>

              {m.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono">
              <Loader2 className="w-4 h-4 animate-spin" /> Sentinel AI is evaluating security intelligence...
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-slate-800/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMsg}
              onChange={(e) => setInputMsg(e.target.value)}
              placeholder="Ask Sentinel AI a cybersecurity or threat question..."
              className="flex-1 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
            />
            <button
              type="submit"
              disabled={loading || !inputMsg.trim()}
              className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs font-mono transition-all flex items-center gap-2"
            >
              <Send className="w-4 h-4" /> SEND
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
