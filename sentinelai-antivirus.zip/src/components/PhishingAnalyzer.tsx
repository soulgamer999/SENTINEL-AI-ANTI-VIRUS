import React, { useState } from 'react';
import {
  Globe,
  Search,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Bot,
  Sparkles,
  Loader2,
  ExternalLink,
  Mail,
  Lock,
} from 'lucide-react';
import { PhishingAnalysisResult } from '../types';
import { samplePhishingInputs } from '../data/mockData';
import { RiskGauge } from './RiskGauge';

export const PhishingAnalyzer: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PhishingAnalysisResult | null>(samplePhishingInputs[0]);

  const handleAnalyze = async (textToAnalyze?: string) => {
    const payload = textToAnalyze || inputText;
    if (!payload.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/analyze-phishing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ textOrUrl: payload }),
      });

      const data = await response.json();
      setResult(data);
    } catch {
      // Fallback response if network error
      setResult({
        input: payload,
        inputType: payload.startsWith('http') ? 'URL' : 'EMAIL_TEXT',
        riskScore: 82,
        classification: 'HIGH_RISK',
        indicators: [
          'Urgent account suspension messaging',
          'Domain mismatch or unverified link target',
          'Requests credential re-verification',
        ],
        explanation: 'SentinelAI evaluated this input as HIGH RISK based on urgency triggers and brand spoofing patterns.',
        recommendedAction: 'Do not interact with link. Flag as Phishing in email gateway.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Globe className="w-6 h-6 text-amber-400" /> AI Phishing & Web Domain Analyzer
          </h1>
          <p className="text-xs text-slate-400">
            Paste suspicious URLs or email text to evaluate domain reputation, typosquatting, urgency triggers, and credential harvest indicators.
          </p>
        </div>
      </div>

      {/* Input Form & Sample Chips */}
      <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 shadow-xl">
        <div className="space-y-2">
          <label className="text-xs font-mono font-bold text-white uppercase block">
            Paste URL, Email Body, or SMS Message:
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="e.g. https://security-verify-bank.com/login or 'URGENT: Your account will be locked in 24 hours...'"
              className="w-full h-24 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono resize-none"
            />
            <button
              onClick={() => handleAnalyze()}
              disabled={loading || !inputText.trim()}
              className="px-6 py-4 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-black text-xs font-mono tracking-wider transition-all shadow-md shadow-amber-500/20 active:scale-95 flex items-center justify-center gap-2 sm:w-48 flex-shrink-0"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> ANALYZING...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" /> ANALYZE INPUT
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Sample Presets */}
        <div className="space-y-2 pt-2 border-t border-slate-800/80">
          <span className="text-[11px] font-mono text-slate-400 block">
            Or test with pre-configured sample inputs:
          </span>
          <div className="flex flex-wrap gap-2 text-xs">
            {samplePhishingInputs.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputText(sample.input);
                  handleAnalyze(sample.input);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-500/50 text-slate-300 font-mono text-[11px] transition-all truncate max-w-xs"
              >
                Sample {idx + 1}: {sample.inputType === 'URL' ? 'Suspicious URL' : 'Urgent Bank SMS'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Analysis Results Display */}
      {result && !loading && (
        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center border-b border-slate-800 pb-6">
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-400 font-bold">
                  {result.inputType}
                </span>
                <span>Submitted Analysis Payload</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-white break-all">
                {result.input}
              </div>
            </div>

            <div className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-[10px] uppercase font-mono font-bold text-slate-400">
                PHISHING RISK INDEX
              </span>
              <RiskGauge score={result.riskScore} classification={result.classification} />
            </div>
          </div>

          {/* Indicators & Explanation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" /> Detected Phishing & Spoofing Indicators
              </h3>
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
                {result.indicators.map((ind, i) => (
                  <div key={i} className="flex items-start gap-2 text-slate-300">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <span>{ind}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <Bot className="w-4 h-4 text-emerald-400" /> Sentinel AI Safety Evaluation
              </h3>
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
                <p className="text-slate-300 leading-relaxed">{result.explanation}</p>
                <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 font-mono">
                  <strong>Recommended Response:</strong> {result.recommendedAction}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
