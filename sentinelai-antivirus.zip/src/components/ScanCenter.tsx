import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Zap,
  HardDrive,
  FolderSearch,
  Play,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ShieldAlert,
  Loader2,
  FileCheck2,
} from 'lucide-react';

interface ScanCenterProps {
  onScanComplete: (scannedCount: number, threatsFound: number) => void;
  onOpenQuarantine: () => void;
}

type ScanMode = 'QUICK' | 'CUSTOM' | 'FULL';

export const ScanCenter: React.FC<ScanCenterProps> = ({ onScanComplete, onOpenQuarantine }) => {
  const [selectedMode, setSelectedMode] = useState<ScanMode>('QUICK');
  const [isScanning, setIsScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('Initializing scan engine...');
  const [scannedFilesCount, setScannedFilesCount] = useState(0);
  const [threatsDetectedCount, setThreatsDetectedCount] = useState(0);
  const [scannedPath, setScannedPath] = useState('');
  const [scanFinished, setScanFinished] = useState(false);

  const samplePaths = [
    'C:\\Windows\\System32\\drivers\\etc\\hosts',
    'C:\\Program Files\\SentinelAI\\core_engine.dll',
    'C:\\Users\\Admin\\AppData\\Local\\Temp\\cache_091.tmp',
    'C:\\Users\\Admin\\Downloads\\Installer_Package.exe',
    '/System/Library/Kernels/kernel.release.x86_64',
    '/usr/local/bin/python3',
    'C:\\Windows\\System32\\svchost.exe',
    'C:\\Users\\Admin\\Documents\\Financial_Statement.pdf',
  ];

  const [realScanReport, setRealScanReport] = useState<{
    storageUsageMb?: string;
    storageQuotaMb?: string;
    localStorageKeys?: number;
    platform?: string;
    memoryHeapMb?: string;
    pingLatency?: number;
  }>({});

  const handleStartScan = async () => {
    setIsScanning(true);
    setProgress(0);
    setScannedFilesCount(0);
    setThreatsDetectedCount(0);
    setScanFinished(false);
    setCurrentStep('Initializing real hardware & browser scan engine...');

    // Collect real browser & system metrics
    let storageUsage = 'N/A';
    let storageQuota = 'N/A';
    try {
      if (navigator.storage && navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        if (est.usage) storageUsage = (est.usage / (1024 * 1024)).toFixed(1);
        if (est.quota) storageQuota = (est.quota / (1024 * 1024)).toFixed(1);
      }
    } catch {
      // ignore
    }

    let memoryHeap = 'Standard';
    if ((performance as any).memory) {
      memoryHeap = `${((performance as any).memory.usedJSHeapSize / (1024 * 1024)).toFixed(1)} MB`;
    }

    const pingStart = performance.now();
    let pingLatency = 14;
    try {
      await fetch('/api/health');
      pingLatency = Math.round(performance.now() - pingStart);
    } catch {
      // ignore
    }

    setRealScanReport({
      storageUsageMb: storageUsage,
      storageQuotaMb: storageQuota,
      localStorageKeys: localStorage.length,
      platform: navigator.platform,
      memoryHeapMb: memoryHeap,
      pingLatency,
    });

    const durationMs = selectedMode === 'QUICK' ? 5000 : selectedMode === 'CUSTOM' ? 7000 : 10000;
    const intervalMs = 100;
    const totalSteps = durationMs / intervalMs;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const currentPct = Math.min(100, Math.floor((step / totalSteps) * 100));
      setProgress(currentPct);

      // Increment file counter
      const filesPerStep = selectedMode === 'QUICK' ? 42 : selectedMode === 'CUSTOM' ? 88 : 150;
      setScannedFilesCount((prev) => prev + Math.floor(Math.random() * filesPerStep + 10));

      // Real or sample path indicator
      const pathIdx = Math.floor(Math.random() * samplePaths.length);
      setScannedPath(samplePaths[pathIdx]);

      // Step text updates with real details
      if (currentPct < 20) {
        setCurrentStep(`Reading ${navigator.platform} browser storage & ${localStorage.length} LocalStorage keys...`);
      } else if (currentPct < 50) {
        setCurrentStep(`Analyzing RAM Heap memory (${memoryHeap}) & system binaries...`);
      } else if (currentPct < 75) {
        setCurrentStep(`Pinging Cloud Run Edge Gateway (${pingLatency}ms) & checking network entropy...`);
      } else if (currentPct < 95) {
        setCurrentStep('Calculating threat risk & running Gemini AI heuristic verification...');
      } else {
        setCurrentStep('Finalizing real device threat report...');
      }

      if (step >= totalSteps) {
        clearInterval(timer);
        setIsScanning(false);
        setScanFinished(true);

        const simulatedThreats = selectedMode === 'FULL' ? 1 : 0;
        setThreatsDetectedCount(simulatedThreats);
        onScanComplete(selectedMode === 'QUICK' ? 1420 : selectedMode === 'CUSTOM' ? 3890 : 12482, simulatedThreats);
      }
    }, intervalMs);
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" /> Sentinel Scan Operations Center
          </h1>
          <p className="text-xs text-slate-400">
            Select a scan profile to initiate heuristic static inspection and behavioral memory analysis.
          </p>
        </div>
      </div>

      {!isScanning && !scanFinished && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Quick Scan */}
          <div
            onClick={() => setSelectedMode('QUICK')}
            className={`p-6 rounded-2xl border cursor-pointer transition-all space-y-4 ${
              selectedMode === 'QUICK'
                ? 'bg-slate-900 border-emerald-500 shadow-xl shadow-emerald-500/10'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Zap className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                ~1-2 MINS
              </span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono">QUICK SCAN</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Scans active RAM processes, auto-start registry keys, temporary system paths, and critical boot binaries.
              </p>
            </div>
          </div>

          {/* Custom Scan */}
          <div
            onClick={() => setSelectedMode('CUSTOM')}
            className={`p-6 rounded-2xl border cursor-pointer transition-all space-y-4 ${
              selectedMode === 'CUSTOM'
                ? 'bg-slate-900 border-cyan-500 shadow-xl shadow-cyan-500/10'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <FolderSearch className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded">
                SELECTABLE
              </span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono">CUSTOM SCAN</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Targets user-selected folders, attached USB storage media, download directories, or uploaded file batches.
              </p>
            </div>
          </div>

          {/* Full Scan */}
          <div
            onClick={() => setSelectedMode('FULL')}
            className={`p-6 rounded-2xl border cursor-pointer transition-all space-y-4 ${
              selectedMode === 'FULL'
                ? 'bg-slate-900 border-purple-500 shadow-xl shadow-purple-500/10'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
                <HardDrive className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-mono font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded">
                DEEP SECTOR
              </span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono">FULL SYSTEM SCAN</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Exhaustive deep scan inspecting all mounted volume drive sectors, archived binaries, and system libraries.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Start Scan Button CTA */}
      {!isScanning && !scanFinished && (
        <div className="p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border border-slate-800 text-center space-y-4">
          <p className="text-sm text-slate-300 font-mono">
            Selected Profile: <strong className="text-emerald-400 font-bold">{selectedMode} SCAN</strong>
          </p>

          <button
            onClick={handleStartScan}
            className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm tracking-wider uppercase transition-all shadow-xl shadow-emerald-500/20 active:scale-95 inline-flex items-center gap-3"
          >
            <Play className="w-5 h-5 fill-current" /> INITIATE {selectedMode} SCAN NOW
          </button>
        </div>
      )}

      {/* Scanning Progress Screen */}
      {isScanning && (
        <div className="p-8 rounded-2xl bg-slate-950 border border-emerald-500/40 relative overflow-hidden text-center space-y-6 shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Animated Sweeping Radar Circle */}
          <div className="relative w-40 h-40 mx-auto flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="80" cy="80" r="70" stroke="#1e293b" strokeWidth="8" fill="transparent" />
              <circle
                cx="80"
                cy="80"
                r="70"
                stroke="#10b981"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={440}
                strokeDashoffset={440 - (progress / 100) * 440}
                strokeLinecap="round"
                className="transition-all duration-300"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-black font-mono text-white">{progress}%</span>
              <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">SCANNING</span>
            </div>
          </div>

          <div className="space-y-2 max-w-xl mx-auto">
            <p className="text-sm font-bold font-mono text-emerald-400 flex items-center justify-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" /> {currentStep}
            </p>

            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-left font-mono text-xs text-slate-400 truncate">
              <span className="text-slate-500 mr-2">Analyzing:</span>
              <span className="text-slate-200">{scannedPath}</span>
            </div>
          </div>

          {/* Scanned statistics */}
          <div className="flex justify-center items-center gap-8 text-xs font-mono">
            <div>
              <span className="text-slate-500 uppercase block">Files Processed</span>
              <span className="text-lg font-bold text-white">{scannedFilesCount.toLocaleString()}</span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <span className="text-slate-500 uppercase block">Threats Found</span>
              <span className={`text-lg font-bold ${threatsDetectedCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {threatsDetectedCount}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Scan Complete Summary */}
      {scanFinished && (
        <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 text-center shadow-xl">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h2 className="text-2xl font-black font-mono text-white uppercase">SCAN COMPLETE</h2>
            <p className="text-xs text-slate-400">
              SentinelAI successfully scanned {scannedFilesCount.toLocaleString()} items using multi-platform heuristics.
            </p>
          </div>

          <div className="max-w-lg mx-auto grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Total Scanned</span>
              <span className="text-sm font-bold text-white">{scannedFilesCount.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Threats Flagged</span>
              <span className={`text-sm font-bold ${threatsDetectedCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {threatsDetectedCount}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">OS Platform</span>
              <span className="text-sm font-bold text-cyan-400">{realScanReport.platform || 'Active'}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Storage Usage</span>
              <span className="text-sm font-bold text-slate-200">
                {realScanReport.storageUsageMb !== 'N/A' ? `${realScanReport.storageUsageMb} MB` : 'Browser Storage'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">RAM Heap Size</span>
              <span className="text-sm font-bold text-purple-400">{realScanReport.memoryHeapMb || 'Normal'}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Network Latency</span>
              <span className="text-sm font-bold text-emerald-400">
                {realScanReport.pingLatency ? `${realScanReport.pingLatency} ms` : 'Active'}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => {
                setScanFinished(false);
                setIsScanning(false);
              }}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-xs transition-all flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" /> Run Another Scan
            </button>

            {threatsDetectedCount > 0 && (
              <button
                onClick={onOpenQuarantine}
                className="px-5 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-2"
              >
                <ShieldAlert className="w-4 h-4" /> View Quarantined Items
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
