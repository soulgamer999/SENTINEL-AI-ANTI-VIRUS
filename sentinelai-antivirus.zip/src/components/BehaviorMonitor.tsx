import React, { useState, useEffect } from 'react';
import {
  Activity,
  Radio,
  Play,
  Pause,
  Filter,
  Plus,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Terminal,
  Monitor,
} from 'lucide-react';
import { BehavioralEvent, SupportedPlatform } from '../types';

interface BehaviorMonitorProps {
  events: BehavioralEvent[];
  onAddEvent: (evt: BehavioralEvent) => void;
}

export const BehaviorMonitor: React.FC<BehaviorMonitorProps> = ({ events, onAddEvent }) => {
  const [filterType, setFilterType] = useState<'ALL' | 'NORMAL' | 'SUSPICIOUS' | 'HIGH_RISK'>('ALL');
  const [isLiveStream, setIsLiveStream] = useState(true);

  // Auto Stream Generator
  useEffect(() => {
    if (!isLiveStream) return;

    const interval = setInterval(() => {
      const randomTypes: Array<'NORMAL' | 'SUSPICIOUS' | 'HIGH_RISK'> = [
        'NORMAL',
        'NORMAL',
        'NORMAL',
        'SUSPICIOUS',
        'HIGH_RISK',
      ];
      const selectedType = randomTypes[Math.floor(Math.random() * randomTypes.length)];

      const platforms: SupportedPlatform[] = ['Windows', 'macOS', 'Linux', 'Android', 'iOS'];
      const platform = platforms[Math.floor(Math.random() * platforms.length)];

      const now = new Date();
      const timestamp = now.toLocaleTimeString();

      let newEvt: BehavioralEvent;

      if (selectedType === 'NORMAL') {
        const normalSamples = [
          { process: 'browser_sandbox.exe', desc: 'Secure HTTPS socket session opened to cdn.jsdelivr.net.' },
          { process: 'code_editor.app', desc: 'Auto-save triggered for workspace file /src/App.tsx.' },
          { process: 'system_daemon', desc: 'Scheduled background memory page compaction finished.' },
        ];
        const s = normalSamples[Math.floor(Math.random() * normalSamples.length)];
        newEvt = {
          id: `evt-${Date.now()}`,
          timestamp,
          type: 'NORMAL',
          source: 'System Monitor',
          processName: s.process,
          pid: Math.floor(Math.random() * 8000 + 1000),
          description: s.desc,
          platform,
        };
      } else if (selectedType === 'SUSPICIOUS') {
        const susSamples = [
          { process: 'unverified_updater.tmp', desc: 'Process attempted to query hidden startup registry keys.' },
          { process: 'background_service.py', desc: 'Outbound TCP connection attempt to unverified IP 185.220.101.4.' },
          { process: 'temp_extractor.exe', desc: 'Unusual file creation in systemAppData/Local/Temp directory.' },
        ];
        const s = susSamples[Math.floor(Math.random() * susSamples.length)];
        newEvt = {
          id: `evt-${Date.now()}`,
          timestamp,
          type: 'SUSPICIOUS',
          source: 'Heuristic Guard',
          processName: s.process,
          pid: Math.floor(Math.random() * 8000 + 1000),
          description: s.desc,
          platform,
          actionTaken: 'Flagged for deep inspection',
        };
      } else {
        const riskSamples = [
          { process: 'rapid_file_writer.bin', desc: 'Mass file modification rate detected across 50 user documents.' },
          { process: 'cmd_powershell_spawn.exe', desc: 'Attempted execution of shadow copy removal command (vssadmin delete).' },
          { process: 'untrusted_kernel_mod.sys', desc: 'Direct memory injection attempt into protected system kernel space.' },
        ];
        const s = riskSamples[Math.floor(Math.random() * riskSamples.length)];
        newEvt = {
          id: `evt-${Date.now()}`,
          timestamp,
          type: 'HIGH_RISK',
          source: 'Sentinel Shield',
          processName: s.process,
          pid: Math.floor(Math.random() * 8000 + 1000),
          description: s.desc,
          platform,
          actionTaken: 'PID Suspended & Isolated by Sentinel AI',
        };
      }

      onAddEvent(newEvt);
    }, 4000);

    return () => clearInterval(interval);
  }, [isLiveStream, onAddEvent]);

  const filteredEvents = events.filter((e) => (filterType === 'ALL' ? true : e.type === filterType));

  const triggerManualSimulation = (type: 'NORMAL' | 'SUSPICIOUS' | 'HIGH_RISK') => {
    const timestamp = new Date().toLocaleTimeString();
    let evt: BehavioralEvent;

    if (type === 'NORMAL') {
      evt = {
        id: `evt-man-${Date.now()}`,
        timestamp,
        type: 'NORMAL',
        source: 'User Demo Trigger',
        processName: 'terminal_bash.sh',
        pid: 4012,
        description: 'User initiated benign shell directory listing (ls -la).',
        platform: 'Linux',
      };
    } else if (type === 'SUSPICIOUS') {
      evt = {
        id: `evt-man-${Date.now()}`,
        timestamp,
        type: 'SUSPICIOUS',
        source: 'User Demo Trigger',
        processName: 'suspicious_helper.exe',
        pid: 6109,
        description: 'Unexpected network socket connection opened to remote non-standard port 9001.',
        platform: 'Windows',
        actionTaken: 'Flagged for inspection',
      };
    } else {
      evt = {
        id: `evt-man-${Date.now()}`,
        timestamp,
        type: 'HIGH_RISK',
        source: 'User Demo Trigger',
        processName: 'rapid_burst_modifier.exe',
        pid: 8821,
        description: 'Rapid modification of 120 files in protected User Documents folder.',
        platform: 'Windows',
        actionTaken: 'Process Suspended by Ransomware Guard',
      };
    }

    onAddEvent(evt);
  };

  return (
    <div className="space-y-6 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-400" /> Real-Time Process Behavior Monitor
          </h1>
          <p className="text-xs text-slate-400">
            Simulated live endpoint process execution feed. Intercepts process spawns, network sockets, and file system traversals.
          </p>
        </div>

        {/* Live Stream Toggle */}
        <button
          onClick={() => setIsLiveStream(!isLiveStream)}
          className={`px-4 py-2 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 transition-all ${
            isLiveStream
              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          {isLiveStream ? (
            <>
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" /> LIVE TELEMETRY: PAUSE
            </>
          ) : (
            <>
              <Play className="w-4 h-4 text-slate-400" /> LIVE TELEMETRY: RESUME
            </>
          )}
        </button>
      </div>

      {/* Manual Simulation Injection Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <span className="text-xs font-mono font-bold text-slate-400 uppercase block">
          Inject Synthetic Test Event (Hackathon Demo Controls):
        </span>
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <button
            onClick={() => triggerManualSimulation('NORMAL')}
            className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-slate-300 font-mono flex items-center gap-2 transition-all"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" /> + Normal Event
          </button>
          <button
            onClick={() => triggerManualSimulation('SUSPICIOUS')}
            className="px-3.5 py-2 rounded-xl bg-slate-950 border border-amber-500/30 hover:border-amber-500 text-amber-300 font-mono flex items-center gap-2 transition-all"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" /> + Suspicious Network Probe
          </button>
          <button
            onClick={() => triggerManualSimulation('HIGH_RISK')}
            className="px-3.5 py-2 rounded-xl bg-slate-950 border border-rose-500/30 hover:border-rose-500 text-rose-300 font-mono flex items-center gap-2 transition-all"
          >
            <Plus className="w-3.5 h-3.5 text-rose-400" /> + High-Risk Burst Traversal
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs font-mono">
          <Filter className="w-4 h-4 text-slate-500" />
          <button
            onClick={() => setFilterType('ALL')}
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              filterType === 'ALL'
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            ALL ({events.length})
          </button>
          <button
            onClick={() => setFilterType('NORMAL')}
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              filterType === 'NORMAL'
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            NORMAL
          </button>
          <button
            onClick={() => setFilterType('SUSPICIOUS')}
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              filterType === 'SUSPICIOUS'
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            SUSPICIOUS
          </button>
          <button
            onClick={() => setFilterType('HIGH_RISK')}
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              filterType === 'HIGH_RISK'
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            HIGH RISK
          </button>
        </div>
      </div>

      {/* Events Feed Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3.5">Time</th>
                <th className="p-3.5">Level</th>
                <th className="p-3.5">Process / PID</th>
                <th className="p-3.5">Platform</th>
                <th className="p-3.5">Behavior Description</th>
                <th className="p-3.5">Action Taken</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredEvents.map((evt) => (
                <tr key={evt.id} className="hover:bg-slate-900/50 transition-colors">
                  <td className="p-3.5 text-slate-400 whitespace-nowrap">{evt.timestamp}</td>
                  <td className="p-3.5 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        evt.type === 'HIGH_RISK'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : evt.type === 'SUSPICIOUS'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {evt.type}
                    </span>
                  </td>
                  <td className="p-3.5 font-bold text-white whitespace-nowrap">
                    {evt.processName} <span className="text-[10px] text-slate-500 font-normal">({evt.pid})</span>
                  </td>
                  <td className="p-3.5 text-cyan-400 whitespace-nowrap">{evt.platform}</td>
                  <td className="p-3.5 text-slate-300 max-w-md truncate">{evt.description}</td>
                  <td className="p-3.5 whitespace-nowrap">
                    {evt.actionTaken ? (
                      <span className="text-rose-400 font-bold">{evt.actionTaken}</span>
                    ) : (
                      <span className="text-slate-500">Allowed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Safety Notice Disclaimer */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
        <Terminal className="w-4 h-4 text-emerald-400 flex-shrink-0" />
        <span>
          <strong>Safety Requirement Notice:</strong> All behavioral events displayed are synthetic simulations generated for demonstration purposes and do NOT execute destructive actions on your local operating system.
        </span>
      </div>
    </div>
  );
};
