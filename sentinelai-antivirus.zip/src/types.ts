export type ThreatLevel = 'SAFE' | 'LOW_RISK' | 'SUSPICIOUS' | 'HIGH_RISK' | 'CRITICAL';

export type ThreatCategory =
  | 'Malware'
  | 'Ransomware'
  | 'Spyware'
  | 'Phishing'
  | 'Suspicious Executable'
  | 'Credential Theft Indicator'
  | 'Unwanted Software'
  | 'Network Anomaly'
  | 'Unknown/Suspicious';

export type SupportedPlatform = 'Windows' | 'macOS' | 'Linux' | 'Android' | 'iOS';

export interface FileAnalysisResult {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  sha256: string;
  uploadTime: string;
  metadata: {
    compiler?: string;
    entropy?: number;
    signatures?: string[];
    packed?: boolean;
    digitalSignature?: 'Valid' | 'Invalid' | 'Unsigned';
    targetOs?: string;
  };
  riskScore: number; // 0 - 100
  classification: ThreatLevel;
  threatCategory: ThreatCategory;
  indicators: string[];
  recommendedAction: 'ALLOW' | 'MONITOR' | 'QUARANTINE' | 'DELETE';
  aiExplanation: string;
  behavioralSummary?: string[];
  isDemoSample?: boolean;
}

export interface BehavioralEvent {
  id: string;
  timestamp: string;
  type: 'NORMAL' | 'SUSPICIOUS' | 'HIGH_RISK';
  source: string;
  processName: string;
  pid: number;
  description: string;
  platform: SupportedPlatform;
  actionTaken?: string;
}

export interface QuarantinedItem {
  id: string;
  fileName: string;
  originalPath: string;
  detectionTime: string;
  riskLevel: ThreatLevel;
  category: ThreatCategory;
  status: 'Quarantined' | 'Restored' | 'Deleted';
  hash: string;
  size: string;
  riskScore: number;
}

export interface ThreatHistoryItem {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  level: ThreatLevel;
  category: ThreatCategory;
  actionTaken: string;
}

export interface PlatformStatus {
  platform: SupportedPlatform;
  agentVersion: string;
  status: 'Protected' | 'Warning' | 'Updating';
  filesScanned: number;
  threatsBlocked: number;
  lastScanTime: string;
  activeProcesses: number;
}

export interface PhishingAnalysisResult {
  input: string; // URL or Message
  inputType: 'URL' | 'EMAIL_TEXT' | 'SMS_MESSAGE';
  riskScore: number;
  classification: ThreatLevel;
  indicators: string[];
  explanation: string;
  recommendedAction: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  relatedThreatId?: string;
}

export interface SystemSecurityStats {
  systemStatus: 'Protected' | 'At Risk' | 'Scanning';
  securityScore: number; // e.g. 94/100
  filesScanned: number;
  threatsDetected: number;
  suspiciousCount: number;
  quarantinedCount: number;
  lastFullScan: string;
}
