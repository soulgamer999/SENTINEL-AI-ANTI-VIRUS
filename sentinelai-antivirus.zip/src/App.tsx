import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { ScanCenter } from './components/ScanCenter';
import { FileAnalyzer } from './components/FileAnalyzer';
import { BehaviorMonitor } from './components/BehaviorMonitor';
import { QuarantineCenter } from './components/QuarantineCenter';
import { AnalyticsView } from './components/AnalyticsView';
import { PhishingAnalyzer } from './components/PhishingAnalyzer';
import { RansomwareGuard } from './components/RansomwareGuard';
import { AiAssistant } from './components/AiAssistant';
import { SettingsView } from './components/SettingsView';
import { Footer } from './components/Footer';

import { AlertCenterOverlay } from './components/AlertCenterOverlay';
import { AdaptiveAiProfile } from './components/AdaptiveAiProfile';
import { NetworkSecurityMap } from './components/NetworkSecurityMap';
import { EmailSecurityAnalyzer } from './components/EmailSecurityAnalyzer';
import { CredentialSafetyCenter } from './components/CredentialSafetyCenter';
import { IncidentResponseCenter } from './components/IncidentResponseCenter';
import { DeveloperSecurityMode } from './components/DeveloperSecurityMode';
import { MultiAgentSecurity } from './components/MultiAgentSecurity';
import { SecurityLab } from './components/SecurityLab';
import { GamificationAchievements } from './components/GamificationAchievements';
import { ThreatHeatmap } from './components/ThreatHeatmap';
import { CommandPalette } from './components/CommandPalette';

import {
  initialSecurityStats,
  platformStatuses,
  initialBehaviorEvents,
  initialQuarantinedItems,
} from './data/mockData';
import {
  FileAnalysisResult,
  BehavioralEvent,
  QuarantinedItem,
} from './types';
import {
  LayoutDashboard,
  Compass,
  ShieldCheck,
  FileSearch,
  Activity,
  ShieldAlert,
  BarChart3,
  Globe,
  Lock,
  Bot,
  Settings,
  X,
  Brain,
  Network,
  Mail,
  KeyRound,
  Code2,
  Beaker,
  Award,
  Flame,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [demoMode, setDemoMode] = useState<boolean>(true);
  const [stats, setStats] = useState(initialSecurityStats);
  const [platforms] = useState(platformStatuses);
  const [behaviorEvents, setBehaviorEvents] = useState<BehavioralEvent[]>(initialBehaviorEvents);
  const [quarantinedItems, setQuarantinedItems] = useState<QuarantinedItem[]>(initialQuarantinedItems);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [globalAlert, setGlobalAlert] = useState<BehavioralEvent | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleQuickScan = () => {
    setActiveTab('scan');
    setIsMobileMenuOpen(false);
  };

  const handleScanComplete = (scannedCount: number, threatsFound: number) => {
    setStats((prev) => ({
      ...prev,
      filesScanned: prev.filesScanned + scannedCount,
      threatsDetected: prev.threatsDetected + threatsFound,
      lastFullScan: 'Just now',
    }));
    showNotification(`Scan completed: ${scannedCount} files processed, ${threatsFound} threats flagged.`);
  };

  const handleQuarantineFile = (file: FileAnalysisResult) => {
    const newItem: QuarantinedItem = {
      id: `q-${Date.now()}`,
      fileName: file.fileName,
      originalPath: `C:\\Users\\Admin\\Downloads\\${file.fileName}`,
      detectionTime: 'Just now',
      riskLevel: file.classification,
      category: file.threatCategory,
      status: 'Quarantined',
      hash: file.sha256,
      size: file.fileSize,
      riskScore: file.riskScore,
    };

    setQuarantinedItems((prev) => [newItem, ...prev]);
    setStats((prev) => ({
      ...prev,
      quarantinedCount: prev.quarantinedCount + 1,
      threatsDetected: prev.threatsDetected + 1,
    }));

    showNotification(`${file.fileName} has been moved to Quarantine Vault.`);
  };

  const handleRestoreQuarantineItem = (id: string) => {
    setQuarantinedItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'Restored' } : item))
    );
    showNotification('Item restored to original directory.');
  };

  const handleDeleteQuarantineItem = (id: string) => {
    setQuarantinedItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'Deleted' } : item))
    );
    showNotification('Item permanently deleted.');
  };

  const handleClearAllQuarantine = () => {
    setQuarantinedItems((prev) =>
      prev.map((item) => ({ ...item, status: 'Deleted' }))
    );
    showNotification('Quarantine vault purged.');
  };

  const handleAddBehaviorEvent = (evt: BehavioralEvent) => {
    setBehaviorEvents((prev) => [evt, ...prev.slice(0, 40)]);
    if (evt.type === 'HIGH_RISK') {
      setGlobalAlert(evt);
    }
  };

  const handleAskAiAboutFile = (file: FileAnalysisResult) => {
    setActiveTab('assistant');
  };

  const mobileNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'threat_heatmap', label: 'Threat Heatmap', icon: Flame },
    { id: 'landing', label: 'Overview', icon: Compass },
    { id: 'scan', label: 'Scan Center', icon: ShieldCheck },
    { id: 'analyzer', label: 'File Analyzer', icon: FileSearch },
    { id: 'behavior', label: 'Behavior Monitor', icon: Activity },
    { id: 'adaptive_ai', label: 'Adaptive AI Engine', icon: Brain },
    { id: 'network_map', label: 'Network & Cloud Map', icon: Network },
    { id: 'email_security', label: 'Email & Web Shield', icon: Mail },
    { id: 'credential_safety', label: 'Credential & Health', icon: KeyRound },
    { id: 'incident_response', label: 'Incident Response', icon: ShieldAlert },
    { id: 'devsec_ops', label: 'DevSecOps Audit', icon: Code2 },
    { id: 'multi_agent', label: 'Multi-Agent AI', icon: Bot },
    { id: 'security_lab', label: 'Defensive Lab', icon: Beaker },
    { id: 'achievements_reports', label: 'Achievements', icon: Award },
    { id: 'quarantine', label: 'Quarantine', icon: ShieldAlert },
    { id: 'phishing', label: 'Phishing Shield', icon: Globe },
    { id: 'ransomware', label: 'Ransomware Guard', icon: Lock },
    { id: 'analytics', label: 'SOC Analytics', icon: BarChart3 },
    { id: 'assistant', label: 'AI Assistant', icon: Bot },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950 antialiased">
      {/* Global Glassmorphism Alert Overlay */}
      <AlertCenterOverlay
        alert={globalAlert}
        onDismiss={() => setGlobalAlert(null)}
        onQuarantineProcess={(evt) => {
          showNotification(`Process ${evt.processName} (PID ${evt.pid}) suspended and isolated.`);
          setGlobalAlert(null);
        }}
        onInvestigateAi={(evt) => {
          setActiveTab('assistant');
          setGlobalAlert(null);
        }}
        onEmergencyIsolate={() => {
          setActiveTab('incident_response');
          setGlobalAlert(null);
        }}
      />

      {/* Toast Notification Banner */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-slate-900 border border-emerald-500/50 text-white font-mono text-xs shadow-2xl flex items-center gap-3 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{notification}</span>
        </div>
      )}

      {/* Top Navigation */}
      <Navbar
        demoMode={demoMode}
        onToggleDemoMode={() => {
          setDemoMode(!demoMode);
          showNotification(`Demo Mode ${!demoMode ? 'ENABLED' : 'DISABLED'}`);
        }}
        securityScore={stats.securityScore}
        onQuickScan={handleQuickScan}
        onOpenMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsMobileMenuOpen(false);
        }}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
      />

      {/* Global Command Palette Modal */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsCommandPaletteOpen(false);
        }}
      />

      {/* Main Layout Body */}
      <div className="flex-1 flex w-full max-w-7xl mx-auto px-4 lg:px-8">
        {/* Desktop Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            setIsMobileMenuOpen(false);
          }}
          quarantinedCount={quarantinedItems.filter((i) => i.status === 'Quarantined').length}
          suspiciousCount={stats.suspiciousCount}
        />

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl lg:hidden p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-mono font-bold text-white text-sm">SENTINEL AI MENU</span>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {mobileNavItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`p-3 rounded-xl border text-left text-xs font-mono font-bold flex items-center gap-2 ${
                      activeTab === item.id
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" /> {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Main Workspace Area */}
        <main className="flex-1 min-w-0 py-4 lg:pl-6">
          {activeTab === 'landing' && (
            <LandingPage
              onStartScan={() => setActiveTab('scan')}
              onAnalyzeFile={() => setActiveTab('analyzer')}
              onOpenDashboard={() => setActiveTab('dashboard')}
              onToggleDemoMode={() => setDemoMode(!demoMode)}
              demoMode={demoMode}
            />
          )}

          {activeTab === 'dashboard' && (
            <Dashboard
              stats={stats}
              platforms={platforms}
              recentEvents={behaviorEvents}
              onSelectTab={setActiveTab}
              onQuickScan={handleQuickScan}
              demoMode={demoMode}
            />
          )}

          {activeTab === 'threat_heatmap' && <ThreatHeatmap />}

          {activeTab === 'scan' && (
            <ScanCenter
              onScanComplete={handleScanComplete}
              onOpenQuarantine={() => setActiveTab('quarantine')}
            />
          )}

          {activeTab === 'analyzer' && (
            <FileAnalyzer
              onAskAiAboutFile={handleAskAiAboutFile}
              onQuarantineFile={handleQuarantineFile}
              demoMode={demoMode}
            />
          )}

          {activeTab === 'behavior' && (
            <BehaviorMonitor
              events={behaviorEvents}
              onAddEvent={handleAddBehaviorEvent}
            />
          )}

          {activeTab === 'adaptive_ai' && <AdaptiveAiProfile />}

          {activeTab === 'network_map' && <NetworkSecurityMap />}

          {activeTab === 'email_security' && <EmailSecurityAnalyzer />}

          {activeTab === 'credential_safety' && <CredentialSafetyCenter />}

          {activeTab === 'incident_response' && <IncidentResponseCenter />}

          {activeTab === 'devsec_ops' && <DeveloperSecurityMode />}

          {activeTab === 'multi_agent' && <MultiAgentSecurity />}

          {activeTab === 'security_lab' && <SecurityLab />}

          {activeTab === 'achievements_reports' && <GamificationAchievements />}

          {activeTab === 'quarantine' && (
            <QuarantineCenter
              items={quarantinedItems}
              onRestore={handleRestoreQuarantineItem}
              onDelete={handleDeleteQuarantineItem}
              onClearAll={handleClearAllQuarantine}
            />
          )}

          {activeTab === 'analytics' && <AnalyticsView />}

          {activeTab === 'phishing' && <PhishingAnalyzer />}

          {activeTab === 'ransomware' && <RansomwareGuard />}

          {activeTab === 'assistant' && <AiAssistant />}

          {activeTab === 'settings' && (
            <SettingsView
              demoMode={demoMode}
              onToggleDemoMode={() => setDemoMode(!demoMode)}
              onResetData={() => {
                setQuarantinedItems(initialQuarantinedItems);
                setBehaviorEvents(initialBehaviorEvents);
                setStats(initialSecurityStats);
                showNotification('Datasets reset to default initial state.');
              }}
            />
          )}
        </main>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}
